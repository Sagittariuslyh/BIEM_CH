function K = L331_final( ct,cl,x1,x2,x3,a1,a2,b1,b2,c1,c2,t )
%L111_FINAL part of Kernel L111

%ѭ�����
part1=L331( ct,cl,x1,x2,x3,a1,a2,b1,b2,t);
part2=L331( ct,cl,x1,x2,x3,c1,c2,a1,a2,t);
part3=L331( ct,cl,x1,x2,x3,b1,b2,c1,c2,t);

K=part1+part2+part3;

end