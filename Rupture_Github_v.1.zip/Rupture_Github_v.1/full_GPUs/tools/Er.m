function err=Er(a1,a2,b1,b2,c1,c2,p1,p2,p3,c,t)
if(c^2*t^2-p3^2)<=0 er=0;
else r=sqrt(c^2*t^2-p3^2);
k=(a1-b1)*(c2-b2)+(b2-a2)*(c1-b1);   
X=(a1-b1)*(p2-b2)+(b2-a2)*(p1-b1)-(b2-a2)*r;
Y=(b1-c1)*(p2-c2)+(c2-b2)*(p1-c1)-(c2-b2)*r;
Z=(c1-a1)*(p2-a2)+(a2-c2)*(p1-a1)-(a2-c2)*r;
[x1,x2]=rk(k*((a1-b1)*(p2-b2)+(b2-a2)*(p1-b1)-(b2-a2)*r),k*2*r*(a1-b1),k*((a1-b1)*(p2-b2)+(b2-a2)*(p1-b1)+(b2-a2)*r));
u=si(k*((a1-b1)*(p2-b2)+(b2-a2)*(p1-b1)-(b2-a2)*r),k*2*r*(a1-b1),k*((a1-b1)*(p2-b2)+(b2-a2)*(p1-b1)+(b2-a2)*r));

[y1,y2]=rk(k*((b1-c1)*(p2-c2)+(c2-b2)*(p1-c1)-(c2-b2)*r),k*2*r*(b1-c1),k*((b1-c1)*(p2-c2)+(c2-b2)*(p1-c1)+(c2-b2)*r));
v=si(k*((b1-c1)*(p2-c2)+(c2-b2)*(p1-c1)-(c2-b2)*r),k*2*r*(b1-c1),k*((b1-c1)*(p2-c2)+(c2-b2)*(p1-c1)+(c2-b2)*r));

[z1,z2]=rk(k*((c1-a1)*(p2-a2)+(a2-c2)*(p1-a1)-(a2-c2)*r),k*2*r*(c1-a1),k*((c1-a1)*(p2-a2)+(a2-c2)*(p1-a1)+(a2-c2)*r));
w=si(k*((c1-a1)*(p2-a2)+(a2-c2)*(p1-a1)-(a2-c2)*r),k*2*r*(c1-a1),k*((c1-a1)*(p2-a2)+(a2-c2)*(p1-a1)+(a2-c2)*r));

if(u>0&&v>0&&w>0)
        er=2*pi+2*(atan(z1)-atan(max(max(x2,y2),z2))-atan(min(max(x2,y2),z1))+atan(max(y1,z2))-atan(max(min(x2,y1),z2))+atan(min(y1,z1))-atan(min(min(x2,y1),z1))+...
                   atan(max(max(x1,y2),z2))-atan(max(y2,z2))+atan(min(max(x1,y2),z1))-atan(min(y2,z1))+atan(max(min(x1,y1),z2))-atan(z2)+atan(min(min(x1,y1),z1)));
   elseif(u<0&&v>0&&w>0)
        er=2*(atan(max(max(x2,y2),z2))-atan(max(max(x1,y2),z2))+atan(min(max(x2,y2),z1))-atan(min(max(x1,y2),z1))+...
              atan(max(min(x2,y1),z2))-atan(max(min(x1,y1),z2))+atan(min(min(x2,y1),z1))-atan(min(min(x1,y1),z1)));
   elseif(u>0&&v<0&&w>0)
        er=2*(atan(max(max(x2,y2),z2))-atan(max(max(y1,x2),z2))+atan(min(max(x2,y2),z1))-atan(min(max(y1,x2),z1))+...
              atan(max(min(y2,x1),z2))-atan(max(min(x1,y1),z2))+atan(min(min(y2,x1),z1))-atan(min(min(x1,y1),z1)));
   elseif(u>0&&v>0&&w<0)
        %er=te110(x1,x2,y1,y2,z1,z2);
        er=2*(atan(max(max(z2,y2),x2))-atan(max(max(z1,y2),x2))+atan(min(max(z2,y2),x1))-atan(min(max(z1,y2),x1))+...
              atan(max(min(z2,y1),x2))-atan(max(min(z1,y1),x2))+atan(min(min(z2,y1),x1))-atan(min(min(z1,y1),x1)));
   elseif(u<0&&v<0&&w>0)
        if(max(x1,y1)>=min(x2,y2))  er=0;
        else er=2*(atan(max(max(x1,y1),z2))-atan(max(min(x2,y2),z2))+atan(min(max(x1,y1),z1))-atan(min(min(x2,y2),z1)));
        end
   elseif(u<0&&v>0&&w<0)
        if(max(x1,z1)>=min(x2,z2))  er=0;
        else er=2*(atan(max(max(x1,z1),y2))-atan(max(min(x2,z2),y2))+atan(min(max(x1,z1),y1))-atan(min(min(x2,z2),y1)));
        end
   elseif(u>0&&v<0&&w<0)
        if(max(z1,y1)>=min(z2,y2))  er=0;
        else er=2*(atan(max(max(z1,y1),x2))-atan(max(min(z2,y2),x2))+atan(min(max(z1,y1),x1))-atan(min(min(z2,y2),x1)));
        end
   elseif(u<0&&v<0&&w<0)
       if(max(max(x1,y1),z1)>=min(min(x2,y2),z2))   er=0;
       else er=2*(atan(max(max(x1,y1),z1))-atan(min(min(x2,y2),z2)));
       end
end
end
err=abs(er);
     
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          