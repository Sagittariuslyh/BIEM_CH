function g2=f2(A,B,C,D,E,y1,y2)
B=B*0.5;
eta1 = E*A - B*D;
ip = A*y1 + B;
jp = A*y2 + B;
i_2=1/((ip+B)*y1+C);
j_2=1/((jp+B)*y2+C);
i_1=sqrt(i_2);
j_1=sqrt(j_2);
i_2j_2=i_2*j_2;
s_2=(ip+jp)*(y1-y2)*i_2j_2;
s_6=s_2*(i_2*i_2+i_2j_2+j_2*j_2);
s_3=s_6/(i_2*i_1+j_2*j_1);
ip=ip*i_1;
jp=jp*j_1;
if (ip>0 && jp>0) || (ip<0 && jp<0)
    ihsp0=1.0/(jp+ip);
    ihsp_2=1.0/(jp*j_2+ip*i_2);
    g2=((s_2*s_2*s_2*A*ihsp0*ihsp0-s_6)*eta1*ihsp_2-D*s_3)/(3.0*A);
else
    sp0=jp-ip;
    sp_2=jp*j_2-ip*i_2;
    ieta = 1.0/(A*C - B*B);
    g2=(eta1*ieta*(2*A*ieta*sp0+sp_2)-D*s_3)/(3.0*A);
end