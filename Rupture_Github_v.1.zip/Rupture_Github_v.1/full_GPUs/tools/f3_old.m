function g3 = f3(A,B,C,D,E,y1,y2)
eta=C*A-B^2/4;
eta1=E*A-B*D/2;
i=(A*y1^2+B*y1+C)^(1/2);
i1=(A*y1+B/2)/i;
j=(A*y2^2+B*y2+C)^(1/2);
j1=(A*y2+B/2)/j;
g3=(eta1*j1*((8*A)/(15*eta^2)+1/(5*A*j^4)+4/(15*eta*j^2))/eta-D/(5*A*j^5))-(eta1*i1*((8*A)/(15*eta^2)+1/(5*A*i^4)+4/(15*eta*i^2))/eta-D/(5*A*i^5));