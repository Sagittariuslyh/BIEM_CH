% �����ٲ������������������ø�Ϊ����
function l = L311( ct,cl,x1,x2,x3,a1,a2,b1,b2,t)
    p=ct/cl;
    A=(b1-a1)^2+(b2-a2)^2;
    B=2*(b1-a1)*(x1-b1)+2*(b2-a2)*(x2-b2);
    C=(x1-b1)^2+(x2-b2)^2+x3^2;
    delta1=B^2-4*A*C+4*A*cl^2.*t.^2;
    delta2=B^2-4*A*C+4*A*ct^2.*t.^2;
    if(delta1>=0)
    r2=(-B+delta1.^(1/2))/(2.*A);
    r1=(-B-delta1.^(1/2))/(2.*A);
    else
        r2=0;r1=0;
    end
    if(delta2>=0)
    rt2=(-B+delta2.^(1/2))/(2.*A);
    rt1=(-B-delta2.^(1/2))/(2.*A);
    else
        rt2=0;rt1=0;
    end
    rB=sqrt(C);
    rA=sqrt((x1-a1)^2+(x2-a2)^2+x3^2);
    if(rB<=cl*t&rA<=cl*t)
    y2=1;y1=0;
    elseif(rB<=cl*t&rA>cl*t)
        y2=r2;y1=0;
    elseif(rB>cl*t&rA<=cl*t)
        y2=1;y1=r1;
    elseif(rB>cl*t&rA>cl*t&-B/(2*A)>0&-B/(2*A)<1&delta1>=0)
        y2=r2;y1=r1;
    else y2=0;y1=0;
    end
    if(rB<=ct*t&rA<=ct*t)
    z2=1;z1=0;
    elseif(rB<=ct*t&rA>ct*t)
        z2=rt2;z1=0;
    elseif(rB>ct*t&rA<=ct*t)
        z2=1;z1=rt1;
    elseif(rB>ct*t&rA>ct*t&-B/(2*A)>0&-B/(2*A)<1&delta2>=0)
        z2=rt2;z1=rt1;
    else z2=0;z1=0;
    end
    
    
    l_1_1=-2*p^3*cl.*t.*f1(A,B,C,b1-a1,x1-b1,y1,y2);
    l_1_2=2*ct^3.*t.^3.*f2(A,B,C,b1-a1,x1-b1,y1,y2);
    l_1_3=6*p^3*cl.*t.*x3^2*f2(A,B,C,b1-a1,x1-b1,y1,y2);
    l_1_4=-10*ct^3.*t.^3*x3^2*f3(A,B,C,b1-a1,x1-b1,y1,y2);
    l_1_5=2*ct.*t.*f1(A,B,C,b1-a1,x1-b1,z1,z2);
    l_1_6=-2*ct^3.*t.^3.*f2(A,B,C,b1-a1,x1-b1,z1,z2);
    l_1_7=-6*ct.*t.*x3^2*f2(A,B,C,b1-a1,x1-b1,z1,z2);
    l_1_8=10*ct^3.*t.^3.*x3^2*f3(A,B,C,b1-a1,x1-b1,z1,z2);
    l_1=l_1_1+l_1_2+l_1_3+l_1_4+l_1_5+l_1_6+l_1_7+l_1_8;
    l_1final=l_1*(a2-b2)/(2*pi);
    l_2final=ct.*t.*(b1-a1)*f1(A,B,C,b2-a2,x2-b2,z1,z2)/(2*pi);
    %l_origin=(-2*p^3*cl.*t.*f1(A,B,C,b1-a1,x1-b1,y1,y2)+2*ct^3.*t.^3.*f2(A,B,C,b1-a1,x1-b1,y1,y2)+6*p^3*cl.*t.*x3^2*f2(A,B,C,b1-a1,x1-b1,y1,y2)-10*ct^3.*t.^3*x3^2*f3(A,B,C,b1-a1,x1-b1,y1,y2)+2*ct.*t.*f1(A,B,C,b1-a1,x1-b1,z1,z2)-2*ct^3.*t.^3.*f2(A,B,C,b1-a1,x1-b1,z1,z2)-6*ct.*t.*x3^2*f2(A,B,C,b1-a1,x1-b1,z1,z2)+10*ct^3.*t.^3.*x3^2*f3(A,B,C,b1-a1,x1-b1,z1,z2))*(a2-b2)/(2*pi)+ct.*t.*(b1-a1)*f1(A,B,C,b2-a2,x2-b2,z1,z2)/(2*pi);
    l=l_1final+l_2final;
    %l=l_origin;
    

end















