function g1 = f1(A,B,C,D,E,y1,y2)
eta=A*C-B^2/4;
eta1=E*A-B*D/2;
i=(A*y1^2+B*y1+C)^(1/2);
i1=(A*y1+B/2)/i;
j=(A*y2^2+B*y2+C)^(1/2);
j1=(A*y2+B/2)/j;
g1=(eta1*j1/(A*eta)-D/(A*j))-(eta1*i1/(A*eta)-D/(A*i));