function K = L311_final( ct,cl,x1,x2,x3,a1,a2,b1,b2,c1,c2,t )
%L311_FINAL part of Kernel L311

%ѭ�����
part1=L311( ct,cl,x1,x2,x3,a1,a2,b1,b2,t);
part2=L311( ct,cl,x1,x2,x3,c1,c2,a1,a2,t);
part3=L311( ct,cl,x1,x2,x3,b1,b2,c1,c2,t);
part4=Er(a1,a2,b1,b2,c1,c2,x1,x2,x3,ct,t);

K=part1+part2+part3+part4/(2*pi);
% K=part4/(2*pi);
end

