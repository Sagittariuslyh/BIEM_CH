function g3=f3(A,B,C,D,E,y1,y2)
B=B*0.5;
eta1 = E*A - B*D;
ip = A*y1 + B;
jp = A*y2 + B;
i_2=1/((ip+B)*y1+C);
j_2=1/((jp+B)*y2+C);
i_1=sqrt(i_2);
j_1=sqrt(j_2);
i_2j_2=i_2*j_2;
i_4=i_2*i_2;
j_4=j_2*j_2;
hs_4=i_4+j_4;
s_2=(ip+jp)*(y1-y2)*i_2j_2;
s_6=s_2*(hs_4+i_2j_2);
s_10=s_2*(i_4*i_4+j_4*j_4)+s_6*i_2j_2;
s_5=s_10/(i_4*i_1+j_4*j_1);
ip=ip*i_1;
jp=jp*j_1;
if (ip>0 && jp>0) || (ip<0 && jp<0)
    ihsp0=1.0/(jp+ip);
    ihsp_2=1.0/(jp*j_2+ip*i_2);
    ihsp_4=1.0/(jp*j_4+ip*i_4);
    hs_2=i_2+j_2;
    s_2s_2=s_2*s_2;
    g3=(((-s_2s_2*s_2*A*ihsp0*ihsp0*ihsp_2*(hs_2*hs_2*ihsp_4+2*ihsp0)+ihsp_4*(hs_4*s_6*ihsp_2+2*i_2j_2*hs_2*s_2*ihsp0))*A*ihsp_2*s_2s_2/3.0-s_10*ihsp_4)*eta1-D*s_5)*0.2/A;
else
    sp0=jp-ip;
    sp_2=jp*j_2-ip*i_2;
    sp_4=jp*j_4-ip*i_4;
    ieta = 1.0/(A*C - B*B);
    Aieta=A*ieta;
    g3=(eta1*ieta*((2*Aieta*sp0+sp_2)*4*Aieta/3.0+sp_4)-D*s_5)*0.2/A;
end