function si=si(a,b,c)
if(a>0) si=1;
elseif(a<0) si=-1;
else
    if(b>0) si=1;
    elseif(b<0) si=-1;
    else
        if(c>=0) si=1;
        else si=-1;
        end
    end
end