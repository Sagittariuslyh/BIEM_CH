function g1=f1(A,B,C,D,E,y1,y2)
B=B*0.5;
eta1=E*A-B*D;
ip=A*y1+B;
jp=A*y2+B;
i_2=1/((ip+B)*y1+C);
j_2=1/((jp+B)*y2+C);
i_1=sqrt(i_2);
j_1=sqrt(j_2);
s_2=-(ip+jp)*(y2-y1)*i_2*j_2;
s_1=s_2/(i_1+j_1);
ip=ip*i_1;
jp=jp*j_1;
if (ip>0 && jp>0) || (ip<0 && jp<0)
    ihsp0=1.0/(jp+ip);
    g1=(-s_2*ihsp0*eta1-D*s_1)/A;
else
    sp0=jp-ip;
    ieta = 1.0/(A*C - B*B);
    g1=(eta1*ieta*sp0-D*s_1)/A;
end