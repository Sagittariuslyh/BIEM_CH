% ȫ�ռ���ֺ˵ļ�Ӧ����������
clear
clc

warning off

addpath('tools')
addpath('halftools')

%% ��ȡ��������
fileID = fopen('Kernel_Input.txt', 'r');
lineNumber = 1;

data = []; % ����һ�����������洢����

while ~feof(fileID)
    line = fgetl(fileID); % ���ж�ȡ
    if ischar(line)
        line = strtrim(strtok(line, '%'));
        % ��ÿ������ת��Ϊ����
        value = str2double(line);
        
        if ~isnan(value)
            % ��ÿ�����ݴ洢��������
            data(lineNumber) = value;
            lineNumber = lineNumber + 1;
        end
    end
end

fclose(fileID);

nCPU=data(1);
%% Ԥ��

mypar=parpool(nCPU); % �������г�

load('point.mat') % ������꣬����p
load('triangle.mat') % �����ζ˵���ţ�����t

typeflag=size(t,2);
if typeflag==4
    type='unstructed'; % �ǽṹ������
elseif typeflag==5
    type='structed'; % �ṹ������
end

kerneltype='half';
kernelclass='single';
%% ��������
ds=data(2);
CFL=data(8);
vc=[data(5),data(6)];%����
dt=CFL*ds/vc(1);%ʱ�䲽
t0=dt*data(3);%���ʱ��
tt=0:dt:t0+2*dt;%ʱ�����У���ֺ��������
rho=data(4);%�����ܶ�
mu=rho*vc(2)^2;%\mu
delta=data(7)*pi/180;%���
Sin=sin(delta);%�������
Cos=cos(delta);%�������
Ln=length(t(:,1));%Դ��Ԫ����
Lm=length(t(:,1));%���յ�Ԫ����
Lt=length(tt);%ʱ�����г��ȣ�ʱ�䲽������
switch kerneltype
    case 'full'
        kernel_T_full=zeros(Ln,Lm,Lt-2);%���ֺ˳�ʼ��
        kernel_N_full=zeros(Ln,Lm,Lt-2);%���ֺ˳�ʼ��
    case 'half'
        kernel_T_half=zeros(Ln,Lm,Lt-2);%���ֺ˳�ʼ��
        kernel_N_half=zeros(Ln,Lm,Lt-2);%���ֺ˳�ʼ��
    otherwise
end
time=0;%����Green����ʱ��t����ʼ����
%% ѭ��������n��m��t��������������ֺˣ�������������ˣ�
tic
parfor_progress(Ln);
parfor i=1:Ln%Դ��Ԫ���
    switch type
        case 'unstructed'
            theta_s=t(i,4); % �����Ի��ֺ�ûӰ��
        case 'structed'
            theta_s=t(i,5);
        otherwise
    end
    for j=1:Lm%����Ԫ���
        switch type
            case 'unstructed'
                theta_r=t(j,4);
            case 'structed'
                theta_r=t(j,5);
            otherwise
        end
        theta=theta_r-theta_s;
        switch type
            case 'unstructed'
                source1=p(t(i,1),:);
                source2=p(t(i,2),:);
                source3=p(t(i,3),:);
                source1=[source1(1),source1(3),source1(2)];
                source2=[source2(1),source2(3),source2(2)];
                source3=[source3(1),source3(3),source3(2)];  
                source=1/3*(source1+source2+source3);
                %���ɽ���
                %���ܵ�Ԫ��������
                receive1=p(t(j,1),:);
                receive2=p(t(j,2),:);
                receive3=p(t(j,3),:);
                receive1=[receive1(1),receive1(3),receive1(2)]; 
                receive2=[receive2(1),receive2(3),receive2(2)];
                receive3=[receive3(1),receive3(3),receive3(2)];
                receive=1/3*(receive1+receive2+receive3);%���յ����꣨��Ԫ���ģ�
            case 'structed'
                source1=p(t(i,1),:);
                source2=p(t(i,2),:);
                source3=p(t(i,3),:);
                source4=p(t(i,4),:);
                source1=[source1(1),source1(3),source1(2)];
                source2=[source2(1),source2(3),source2(2)];
                source3=[source3(1),source3(3),source3(2)];
                source4=[source4(1),source4(3),source4(2)];
                source=1/4*(source1+source2+source3+source4);
                %���ɽ���
                %���ܵ�Ԫ��������
                receive1=p(t(j,1),:);
                receive2=p(t(j,2),:);
                receive3=p(t(j,3),:);
                receive4=p(t(j,4),:);
                receive1=[receive1(1),receive1(3),receive1(2)];
                receive2=[receive2(1),receive2(3),receive2(2)];
                receive3=[receive3(1),receive3(3),receive3(2)];
                receive4=[receive4(1),receive4(3),receive4(2)];
                receive=1/4*(receive1+receive2+receive3+receive4);%���յ����꣨��Ԫ���ģ�
            otherwise
        end
        
        %������ֺ�
        ct=vc(2);
        cl=vc(1);
        a111=[];
        a121=[];
        a131=[];
        theta2=theta;
        transfer=[cos(theta_s),-sin(theta_s),0;sin(theta_s),cos(theta_s),0;0,0,1]; % �任��Դ��������Ƕȵ�����ϵ
        receive=receive*transfer;
        source=source*transfer;
        source1=source1*transfer;
        source2=source2*transfer;
        source3=source3*transfer;
        if i==j
            x2=receive(2)-source1(2)+0.0001;
        else
            x2=receive(2)-source1(2);
        end

        switch type
            case 'unstructed'
                source=1/3*(source1+source2+source3);

                d1=norm(source1-source2);
                d2=norm(source2-source3);
                d3=norm(source3-source1);
                pp=(d1+d2+d3)/2;
                dS=sqrt(pp*(pp-d1)*(pp-d2)*(pp-d3));%��������������׹�ʽ��
            case 'structed'
                source4=source4*transfer;
                source=1/4*(source1+source2+source3+source4);

                d1=norm(source1-source2);
                d2=norm(source1-source4);
                dS=d1*d2;%���������(���˿�)
            otherwise
        end
        h=source(3);
        x=[receive(1)-source(1),receive(2)-source(2),receive(3)];
        switch kerneltype
            case 'full'
                tt=0:dt:t0+dt;
                for k=1:1:length(tt)           
                    switch type
                        case 'unstructed'
                            % �����λ��Ԫ���������⣬��ؼ��ʱ�䲽��������ߴ��Ƿ�ƥ��
                            a111(k)=L111_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source2(1),source2(3),source3(1),source3(3),tt(k));
                            a121(k)=L311_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source2(1),source2(3),source3(1),source3(3),tt(k));
                            a131(k)=L331_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source2(1),source2(3),source3(1),source3(3),tt(k));
                        case 'structed'
                            a111(k)=L111_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source3(1),source3(3),source2(1),source2(3),tt(k))+...
                                L111_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source4(1),source4(3),source3(1),source3(3),tt(k));
                            a121(k)=L311_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source3(1),source3(3),source2(1),source2(3),tt(k))+...
                                L311_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source4(1),source4(3),source3(1),source3(3),tt(k));
                            a131(k)=L331_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source3(1),source3(3),source2(1),source2(3),tt(k))+...
                                L331_final(ct,cl,receive(1),receive(3),x2,source1(1),source1(3),source4(1),source4(3),source3(1),source3(3),tt(k));
                        otherwise
                    end
                end
                yyfull111=a111;
                yyfull311=a121;
                yyfull331=a131;
                yyfull_T=(yyfull331-yyfull111)*sin(theta2)*cos(theta2)+yyfull311*(cos(theta2)^2-sin(theta2)^2);
                yyfull_N=(yyfull331+yyfull111)/2+(yyfull331-yyfull111)*(cos(theta2)^2-sin(theta2)^2)/2-yyfull311*2*sin(theta2)*cos(theta2);
                yyfull_T=-mu/(2*vc(2))*diff(yyfull_T,1);
                yyfull_N=-mu/(2*vc(2))*diff(yyfull_N,1);
                kernel_T_full(i,j,:)=yyfull_T;
                kernel_N_full(i,j,:)=yyfull_N;
            case 'half'
                vector1=source2-source1;
                vector2=source4-source1;
                Distance=norm([receive(1)-source(1),receive(2)-source(2),receive(3)+source(3)]);
                tss=Distance/ct;

                if Distance<2
                    grade=5;
                elseif Distance>=2 && Distance<15
                    grade=4;
                elseif Distance>=15 && Distance<20
                    grade=3;
                else
                    grade=1;
                end

                % Gauss���ֵ�
                switch grade
                    case 1
                        %% ����1
                        GaussWeight=1/4*[4];
                        GaussAxis1=1/2*(1+[0]);
                        GaussAxis2=1/2*(1+[0]);
                    case 2
                        %% ����2
                        GaussWeight=1/4*[1 1 1 1];
                        GaussAxis1=1/2*(1+[-0.57735027 -0.57735027 0.57735027 0.57735027]);
                        GaussAxis2=1/2*(1+[-0.57735027 0.57735027 -0.57735027 0.57735027]);
                    case 3
                        %% ����3
                        GaussWeight=1/4*[0.30864198 0.49382716 0.30864198 0.49382716 0.79012346 0.49382716 ...
                                     0.30864198 0.49382716 0.30864198];
                        GaussAxis1=1/2*(1+[-0.77459667 -0.77459667 -0.77459667 0 0 0 ...
                                     0.77459667 0.77459667 0.77459667]);
                        GaussAxis2=1/2*(1+[-0.77459667 0 0.77459667 -0.77459667 0 0.77459667 ...
                                     -0.77459667 0 0.77459667]);
                    case 4
                        %% ����4
                        GaussWeight=1/4*[0.12100299 0.22685185 0.22685185 0.12100299 0.22685185 0.4252933 ...
                         0.4252933  0.22685185 0.22685185 0.4252933  0.4252933  0.22685185 ...
                         0.12100299 0.22685185 0.22685185 0.12100299];
                        GaussAxis1=1/2*(1+[-0.86113631 -0.86113631 -0.86113631 -0.86113631 ...
                                           -0.33998104 -0.33998104 -0.33998104 -0.33998104 ...
                                           0.33998104 0.33998104 0.33998104 0.33998104 ...
                                           0.86113631 0.86113631 0.86113631 0.86113631]);
                        GaussAxis2=1/2*(1+[-0.86113631 -0.33998104 0.33998104 0.86113631 ...
                                           -0.86113631 -0.33998104 0.33998104 0.86113631 ...
                                           -0.86113631 -0.33998104 0.33998104 0.86113631 ...
                                           -0.86113631 -0.33998104 0.33998104 0.86113631]);
                    case 5
                        %% ����5
                        GaussWeight=1/4*[0.05613435 0.1134     0.13478507 0.1134     0.05613435 0.1134 ...
                                         0.2290854  0.27228653 0.2290854  0.1134     0.13478507 0.27228653 ...
                                         0.32363457 0.27228653 0.13478507 0.1134     0.2290854  0.27228653 ...
                                         0.2290854  0.1134     0.05613435 0.1134     0.13478507 0.1134 ...
                                         0.05613435];
                        GaussAxis1=1/2*(1+[-0.90617985 -0.90617985 -0.90617985 -0.90617985 -0.90617985 ...
                                           -0.53846931 -0.53846931 -0.53846931 -0.53846931 -0.53846931 ...
                                           0 0 0 0 0 ...
                                           0.53846931 0.53846931 0.53846931 0.53846931 0.53846931 ...
                                           0.90617985 0.90617985 0.90617985 0.90617985 0.90617985]);
                        GaussAxis2=1/2*(1+[-0.90617985 -0.53846931 0 0.53846931 0.90617985 ...
                                           -0.90617985 -0.53846931 0 0.53846931 0.90617985 ...
                                           -0.90617985 -0.53846931 0 0.53846931 0.90617985 ...
                                           -0.90617985 -0.53846931 0 0.53846931 0.90617985 ...
                                           -0.90617985 -0.53846931 0 0.53846931 0.90617985]);
                    case 6
                        %% ����6
                        GaussWeight=1/4*[0.02935208 0.06180729 0.08016512 0.08016512 0.06180729 0.02935208 ...
                                         0.06180729 0.13014891 0.16880537 0.16880537 0.13014891 0.06180729 ...
                                         0.08016512 0.16880537 0.21894345 0.21894345 0.16880537 0.08016512 ...
                                         0.08016512 0.16880537 0.21894345 0.21894345 0.16880537 0.08016512 ...
                                         0.06180729 0.13014891 0.16880537 0.16880537 0.13014891 0.06180729 ...
                                         0.02935208 0.06180729 0.08016512 0.08016512 0.06180729 0.02935208];
                        GaussAxis1=1/2*(1+[-0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951 ...
                                           -0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951 ...
                                           -0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951 ...
                                           -0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951 ...
                                           -0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951 ...
                                           -0.93246951 -0.66120939 -0.23861919  0.23861919  0.66120939  0.93246951]);
                        GaussAxis2=1/2*(1+[-0.93246951 -0.93246951 -0.93246951 -0.93246951 -0.93246951 -0.93246951 ...
                                           -0.66120939 -0.66120939 -0.66120939 -0.66120939 -0.66120939 -0.66120939 ...
                                           -0.23861919 -0.23861919 -0.23861919 -0.23861919 -0.23861919 -0.23861919 ...
                                           0.23861919  0.23861919  0.23861919  0.23861919  0.23861919  0.23861919 ...
                                           0.66120939  0.66120939  0.66120939  0.66120939  0.66120939  0.66120939 ...
                                           0.93246951  0.93246951  0.93246951  0.93246951  0.93246951  0.93246951]);
                    
                    case 7
                        %% ����7
                        GaussWeight=1/4*[0.01676636 0.03621764 0.04944125 0.05411943 0.04944125 0.03621764 ...
                                         0.01676636 0.03621764 0.07823511 0.10679992 0.11690544 0.10679992 ...
                                         0.07823511 0.03621764 0.04944125 0.10679992 0.14579419 0.15958938 ...
                                         0.14579419 0.10679992 0.04944125 0.05411943 0.11690544 0.15958938 ...
                                         0.17468988 0.15958938 0.11690544 0.05411943 0.04944125 0.10679992 ...
                                         0.14579419 0.15958938 0.14579419 0.10679992 0.04944125 0.03621764 ...
                                         0.07823511 0.10679992 0.11690544 0.10679992 0.07823511 0.03621764 ...
                                         0.01676636 0.03621764 0.04944125 0.05411943 0.04944125 0.03621764 ...
                                         0.01676636];
                        GaussAxis1=1/2*(1+[-0.94910791 -0.94910791 -0.94910791 -0.94910791 -0.94910791 -0.94910791 ...
                                             -0.94910791 -0.74153119 -0.74153119 -0.74153119 -0.74153119 -0.74153119 ...
                                             -0.74153119 -0.74153119 -0.40584515 -0.40584515 -0.40584515 -0.40584515 ...
                                             -0.40584515 -0.40584515 -0.40584515  0.          0.          0. ...
                                              0.          0.          0.          0.          0.40584515  0.40584515 ...
                                              0.40584515  0.40584515  0.40584515  0.40584515  0.40584515  0.74153119 ...
                                              0.74153119  0.74153119  0.74153119  0.74153119  0.74153119  0.74153119 ...
                                              0.94910791  0.94910791  0.94910791  0.94910791  0.94910791  0.94910791 ...
                                              0.94910791]);
                        GaussAxis2=1/2*(1+[-0.94910791 -0.74153119 -0.40584515  0.          0.40584515  0.74153119 ...
                                              0.94910791 -0.94910791 -0.74153119 -0.40584515  0.          0.40584515 ...
                                              0.74153119  0.94910791 -0.94910791 -0.74153119 -0.40584515  0. ...
                                              0.40584515  0.74153119  0.94910791 -0.94910791 -0.74153119 -0.40584515 ...
                                              0.          0.40584515  0.74153119  0.94910791 -0.94910791 -0.74153119 ...
                                             -0.40584515  0.          0.40584515  0.74153119  0.94910791 -0.94910791 ...
                                             -0.74153119 -0.40584515  0.          0.40584515  0.74153119  0.94910791 ...
                                             -0.94910791 -0.74153119 -0.40584515  0.          0.40584515  0.74153119 ...
                                              0.94910791]);
                    case 8
                        %% ����8
                        GaussWeight=1/4*[0.01024722 0.02251131 0.03175606 0.03671395 0.03671395 0.03175606 ...
                                         0.02251131 0.01024722 0.02251131 0.04945332 0.06976241 0.08065399 ...
                                         0.08065399 0.06976241 0.04945332 0.02251131 0.03175606 0.06976241 ...
                                         0.09841186 0.11377631 0.11377631 0.09841186 0.06976241 0.03175606 ... 
                                         0.03671395 0.08065399 0.11377631 0.13153953 0.13153953 0.11377631 ... 
                                         0.08065399 0.03671395 0.03671395 0.08065399 0.11377631 0.13153953 ...
                                         0.13153953 0.11377631 0.08065399 0.03671395 0.03175606 0.06976241 ...
                                         0.09841186 0.11377631 0.11377631 0.09841186 0.06976241 0.03175606 ...
                                         0.02251131 0.04945332 0.06976241 0.08065399 0.08065399 0.06976241 ...
                                         0.04945332 0.02251131 0.01024722 0.02251131 0.03175606 0.03671395 ...
                                         0.03671395 0.03175606 0.02251131 0.01024722];
                        GaussAxis1=1/2*(1+[-0.96028986 -0.96028986 -0.96028986 -0.96028986 -0.96028986 -0.96028986 ...
                                             -0.96028986 -0.96028986 -0.79666648 -0.79666648 -0.79666648 -0.79666648 ...
                                             -0.79666648 -0.79666648 -0.79666648 -0.79666648 -0.52553241 -0.52553241 ...
                                             -0.52553241 -0.52553241 -0.52553241 -0.52553241 -0.52553241 -0.52553241 ...
                                             -0.18343464 -0.18343464 -0.18343464 -0.18343464 -0.18343464 -0.18343464 ...
                                             -0.18343464 -0.18343464  0.18343464  0.18343464  0.18343464  0.18343464 ...
                                              0.18343464  0.18343464  0.18343464  0.18343464  0.52553241  0.52553241 ...
                                              0.52553241  0.52553241  0.52553241  0.52553241  0.52553241  0.52553241 ...
                                              0.79666648  0.79666648  0.79666648  0.79666648  0.79666648  0.79666648 ...
                                              0.79666648  0.79666648  0.96028986  0.96028986  0.96028986  0.96028986 ...
                                              0.96028986  0.96028986  0.96028986  0.96028986]);
                        GaussAxis2=1/2*(1+[-0.96028986 -0.79666648 -0.52553241 -0.18343464  0.18343464  0.52553241 ...
                                              0.79666648  0.96028986 -0.96028986 -0.79666648 -0.52553241 -0.18343464 ...
                                              0.18343464  0.52553241  0.79666648  0.96028986 -0.96028986 -0.79666648 ... 
                                             -0.52553241 -0.18343464  0.18343464  0.52553241  0.79666648  0.96028986 ...
                                             -0.96028986 -0.79666648 -0.52553241 -0.18343464  0.18343464  0.52553241 ...
                                              0.79666648  0.96028986 -0.96028986 -0.79666648 -0.52553241 -0.18343464 ...
                                              0.18343464  0.52553241  0.79666648  0.96028986 -0.96028986 -0.79666648 ... 
                                             -0.52553241 -0.18343464  0.18343464  0.52553241  0.79666648  0.96028986 ...
                                             -0.96028986 -0.79666648 -0.52553241 -0.18343464  0.18343464  0.52553241 ...
                                              0.79666648  0.96028986 -0.96028986 -0.79666648 -0.52553241 -0.18343464 ...
                                              0.18343464  0.52553241  0.79666648  0.96028986]);
                    otherwise
                end

                tt=0:dt:t0+2*dt;

                G3123=zeros(1,length(tt));
                G3213=zeros(1,length(tt));
                G1112=zeros(1,length(tt));
                G1211=zeros(1,length(tt));
                G2122=zeros(1,length(tt));
                G2212=zeros(1,length(tt));
                G2112=zeros(1,length(tt));
                G2211=zeros(1,length(tt));
                G1122=zeros(1,length(tt));
                G1212=zeros(1,length(tt));
                yyhalf111=zeros(1,length(tt)-2);
                yyhalf311=zeros(1,length(tt)-2);
                yyhalf331=zeros(1,length(tt)-2);

                % ���ջ��ֵ㿪ʼѭ��
                for point=1:length(GaussWeight)                   
                    GaussSource=source1+GaussAxis1(point)*vector1+GaussAxis2(point)*vector2;
                    h=GaussSource(3);
                    x=[receive(1)-GaussSource(1),receive(2)-GaussSource(2),receive(3)];
                    if abs(x(1))<=1e-4 && abs(x(2))<=1e-4
                        x(2)=x(2)+0.0001; 
                    end
                    for k=1:length(tt) 
                        time=tt(k);
                        if k>(tss+0.35)/dt+2
                            G3123(k)=G3123(k-1);
                            G3213(k)=G3213(k-1);
                            G1112(k)=G1112(k-1);
                            G1211(k)=G1211(k-1);
                            G2122(k)=G2122(k-1);
                            G2212(k)=G2212(k-1);
                            G2112(k)=G2112(k-1);
                            G2211(k)=G2211(k-1);
                            G1122(k)=G1122(k-1);
                            G1212(k)=G1212(k-1);
                        else
                            if theta_r==0 && theta_s==0
                                G3123(k)=0;
                                G3213(k)=0;
                                G1112(k)=0;
                                G1211(k)=0;
                                G2122(k)=0;
                                G2212(k)=0;
                            else
                                G3123(k)=Lamb3x3_integral(x,h,time,vc,312);
                                G3213(k)=Lamb3x3_integral(x,h,time,vc,321);
                                G1112(k)=Lamb3_integral(x,h,time,vc,1112);
                                G1211(k)=Lamb3_integral(x,h,time,vc,1211);
                                G2122(k)=Lamb3_integral(x,h,time,vc,2122);
                                G2212(k)=Lamb3_integral(x,h,time,vc,2212);
                            end
                            G2112(k)=Lamb3_integral(x,h,time,vc,2112);
                            G2211(k)=Lamb3_integral(x,h,time,vc,2211);
                            G1122(k)=Lamb3_integral(x,h,time,vc,1122);
                            G1212(k)=Lamb3_integral(x,h,time,vc,1212);
                        end
                    end
                    % �����󵼲���
                    G3123=diff(G3123(1:end-1),1);
                    G3213=diff(G3213(1:end-1),1);
                    G1112=diff(G1112,2)/dt;
                    G1211=diff(G1211,2)/dt;
                    G2122=diff(G2122,2)/dt;
                    G2212=diff(G2212,2)/dt;
                    G2112=diff(G2112,2)/dt;
                    G2211=diff(G2211,2)/dt;
                    G1122=diff(G1122,2)/dt;
                    G1212=diff(G1212,2)/dt;
                    %%%%%%%%%%%%%%%%%%%%%%%
                    dyyhalf311=(G2112+G2211+G1122+G1212);
                    yyhalf111=yyhalf111+dS*GaussWeight(point)*((G3123+G3213-G1112-G1211-G2122-G2212)-(G1112+G1211));
                    yyhalf311=yyhalf311+dS*GaussWeight(point)*((G2112+G2211+G1122+G1212));
                    yyhalf331=yyhalf331+dS*GaussWeight(point)*((G3123+G3213-G1112-G1211-G2122-G2212)-(G2122+G2212));
                end
                for k=1:length(yyhalf111)
                    if k>(tss+0.35)/dt
                        yyhalf111(k)=yyhalf111(k-1);
                        yyhalf311(k)=yyhalf311(k-1);
                        yyhalf331(k)=yyhalf331(k-1);
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%
                yyhalf_T=(yyhalf331-yyhalf111)*sin(theta2)*cos(theta2)+yyhalf311*(cos(theta2)^2-sin(theta2)^2);
                yyhalf_N=(yyhalf331+yyhalf111)/2+(yyhalf331-yyhalf111)*(cos(theta2)^2-sin(theta2)^2)/2-yyhalf311*2*sin(theta2)*cos(theta2);
                %%%%%%%%%%%%%%%%%%%%%%%
                yyhalf_T=-mu^2/rho*yyhalf_T;
                yyhalf_N=-mu^2/rho*yyhalf_N;
                kernel_T_half(i,j,:)=yyhalf_T;
                kernel_N_half(i,j,:)=yyhalf_N;
            otherwise
        end
    end
    parfor_progress;
end
parfor_progress(0);

delete(mypar);

toc


%% �洢
if kernelclass=='single'
    switch kerneltype
        case 'full'
            kernel_T_full=single(kernel_T_full);
            kernel_N_full=single(kernel_N_full);
            save('Knmt311_1_full.mat','kernel_T_full','-v7.3')
            save('Knmt331_1_full.mat','kernel_N_full','-v7.3')
        case 'half'
            kernel_T_half=single(kernel_T_half);
            kernel_N_half=single(kernel_N_half);
            save('Knmt311_1_half.mat','kernel_T_half','-v7.3')
            save('Knmt331_1_half.mat','kernel_N_half','-v7.3')
        otherwise
    end
else
    switch kerneltype
        case 'full'
            save('Knmt311_1_full.mat','kernel_T_full','-v7.3')
            save('Knmt331_1_full.mat','kernel_N_full','-v7.3')
        case 'half'
            save('Knmt311_1_half.mat','kernel_T_half','-v7.3')
            save('Knmt331_1_half.mat','kernel_N_half','-v7.3')
        otherwise
    end
end