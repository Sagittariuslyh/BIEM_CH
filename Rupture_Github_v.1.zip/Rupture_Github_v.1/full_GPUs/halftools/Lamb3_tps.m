function t = Lamb3_tps(x,h,vc)
%% ���� PS ���ĵ�ʱ
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
threshold = 1e-10;
x1=x(1);
x2=x(2);
x3=x(3);
R=sqrt(x1^2+x2^2);
alpha=vc(1);
beta=vc(2);
kk=beta/alpha;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a1=1-kk^2;
a2=-2*R*(1-kk^2);
a3=-kk^2*(x3^2+R^2)+R^2+h^2;
a4=-2*R*h^2;
a5=R^2*h^2;
Raa=roots([a1,a2,a3,a4,a5]);
for i=1:1:4
    if(-threshold<=real(Raa(i))&&(real(Raa(i))<R+threshold)&&imag(Raa(i))<threshold)
        Ra=real(Raa(i));
    break;
    end
end
t=sqrt(Ra^2+h^2)/alpha+sqrt((R-Ra)^2+x3^2)/beta;