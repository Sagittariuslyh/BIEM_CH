function result=Lamb3sp_integral(x, h, t, vc, ori)
%% The SP part of the Green function (54)
% �� PS part ��ȣ���������� (1) �� x3 �� h ����
% (2) ���׶��� PS ij = -SP ji when ij =(13) (23) (31) (32)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1 = x(1);
x2 = x(2);
x3 = x(3);
alpha = vc(1);
beta = vc(2);
R = sqrt(x1^2+x2^2); 
phi = atan(x2/x1);
k = alpha/beta;
Tp = alpha*t/R;
zbar = x3/R;
z = h/R;
A = alpha^(-1)*sqrt(k^2-1);
t3 = Lamb3_tsp(x,h,vc);
if(t<t3)
    result=0;
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
a=1+(z+zbar)^2;
b=-4*Tp*(k^2-1)^(-1/2)*(z+zbar);
c=2*(z^2-zbar^2+(2*Tp^2-k^2-1)/(k^2-1));
d=-4*Tp*(k^2-1)^(-1/2)*(z-zbar);
e=1+(z-zbar)^2;
root1=roots([a,b,c,d,e]);  
root11=max(root1);
r1=norm(root11)^2;
q1=-real(root11);
root13=min(root1);
r2=norm(root13)^2;
q2=-real(root13); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root2=roots([q2-q1,r2-r1,q1*r2-q2*r1]);
xi1=max(root2);
xi2=min(root2);
b1=-(xi2+q1);
c1=xi1+q1;
b2=-(xi2+q2);
c2=xi1+q2;
tau=sqrt(b2*c1/(b1*c2));  %��׼��Բ���ֵĲ���
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xx=@(w)(1i*xi2*sqrt(c1/b1)*sin(w)-xi1)./(1i*sqrt(c1/b1)*sin(w)-1);  
sigma=@(w)(xx(w).^6+(1+2/(k^2-1)^2)*xx(w).^4-(k^2+3)/(k^2-1)*xx(w).^2+1); 
I1=@(w)((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).^2.*(xx(w).^2+1);
I2=@(w)(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*(xx(w).^2+1);
Z=@(w)(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1);
Q=@(w)((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar));
W=@(w)((I1(w)+I2(w))./(xx(w).^2+1));
Sin=sin(phi);
Cos=cos(phi);
switch ori
    case 11                                              
    y=@(w)cos(2*phi)*I1(w)-sin(phi)^2*I2(w);
    case {12,21}
    y=@(w)2*sin(phi)*cos(phi)*I1(w)+sin(phi)*cos(phi)*I2(w);
    case 22
    y=@(w)-cos(2*phi)*I1(w)-cos(phi)^2*I2(w);
    case 31
    y=@(w)-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*cos(phi);
    case 32
    y=@(w)-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*sin(phi);
    case 13
    y=@(w)(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*cos(phi);
    case 23
    y=@(w)(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*sin(phi);
    case 33
    y=@(w)-(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*(xx(w).^2-1);
end 
%% 1����ƫ����
switch ori
    case 111
    y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Cos^2-3*(I1(w)+I2(w))*Sin^2));
    case {121,211}
    y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Cos^2+(I1(w)+I2(w))*(3*Cos^2-1)));
    case 221
    y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Sin^2+(I1(w)+I2(w))*(3*Sin^2-1)));
    case 311
    y = @(w)2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(I1(w)*Cos^2-(I1(w)+I2(w))*Sin^2));
    case 321
    y = @(w)2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(2*I1(w)+I2(w))*Sin*Cos);
    case 131
    y = @(w)2*(1/4*A./xx(w)).*(Z(w).*(1./(xx(w).^2+1)).*(I1(w)*Cos^2-(I1(w)+I2(w))*Sin^2));
    case 231
    y = @(w)2*(1/4*A./xx(w)).*(Z(w).*(1./(xx(w).^2+1)).*(2*I1(w)+I2(w))*Sin*Cos);
    case 331
    y = @(w)2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*Z(w).*Q(w)*Cos);
    otherwise
end
%% 2����ƫ������
switch ori
    case 112
        y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Cos^2+(I1(w)+I2(w))*(3*Cos^2-1)));
    case {122,212}
        y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Sin^2+(I1(w)+I2(w))*(3*Sin^2-1)));
    case 222
        y = @(w)2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Sin^2-3*(I1(w)+I2(w))*Cos^2));
    case 312
        y = @(w)2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(2*I1(w)+I2(w))*Sin*Cos);
    case 322
        y = @(w)2*(-1/4*A./xx(w)).*((xx(w).^2-1).*(I1(w)*Sin^2-(I1(w)+I2(w))*Cos^2));
    case 132
        y = @(w)2*(-1/4*A./xx(w)).*(-Z(w).*(1./(xx(w).^2+1)).*(2*I1(w)+I2(w))*Sin*Cos);
    case 232
        y = @(w)2*(-1/4*A./xx(w)).*(-Z(w).*(1./(xx(w).^2+1)).*(I1(w)*Sin^2-(I1(w)+I2(w))*Cos^2));
    case 332
        y = @(w)2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*Z(w).*Q(w)*Sin);
    otherwise
end
%% 3����ƫ������
switch ori
    case 113                                              
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(cos(2*phi)*I1(w)-sin(phi)^2*I2(w));
    case {123,213}
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*sin(phi)*cos(phi)*I1(w)+sin(phi)*cos(phi)*I2(w));
    case 223
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-cos(2*phi)*I1(w)-cos(phi)^2*I2(w));
    case 313
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*cos(phi));
    case 323
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*sin(phi));
    case 133
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*((xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*cos(phi));
    case 233
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*((xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*sin(phi));
    case 333
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*(xx(w).^2-1));
end 
%% 11����ƫ������
switch ori
    case 1111
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*(Q(w).^4*Cos^4-6*Q(w).^2.*(I1(w)+I2(w))./(xx(w).^2+1)*Sin^2*Cos^2+(I1(w)+I2(w)).^2./(xx(w).^2+1).^2*Sin^4);
    case {1211,2111}
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((W(w)+Q(w).^2).*(Q(w).^2*Cos^2-W(w)*Sin^2)*Sin*Cos+2*Q(w).^2.*W(w)*(Cos^2-Sin^2)*Cos*Sin);
    case 2211
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((Q(w).^2+W(w)).^2*Cos^2*Sin^2-Q(w).^2.*W(w)*(Cos^2-Sin^2)^2);
    case 3111
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Cos.*(Q(w).^2*Cos^2-3*W(w)*Sin^2));
    case 3211
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Sin.*(Q(w).^2*Cos^2+W(w)*(3*Cos^2-1)));
    case 1311
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w)).*(Q(w)*Cos.*(Q(w).^2*Cos^2-3*W(w)*Sin^2));
    case 2311
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w)).*(Q(w)*Sin.*(Q(w).^2*Cos^2+W(w)*(3*Cos^2-1)));
    case 3311
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(-Z(w)).*(xx(w).^2-1).*(Q(w).^2*Cos^2-W(w)*Sin^2);
    otherwise
end
%% 22����ƫ������
switch ori
    case 1122
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((Q(w).^2+W(w)).^2*Cos^2*Sin^2-Q(w).^2.*W(w)*(Cos^2-Sin^2)^2);
    case {1222,2122}
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((Q(w).^2+W(w)).*(Q(w).^2*Sin^2-W(w)*Cos^2)*Sin*Cos-2*W(w).*Q(w).^2*(Cos^2-Sin^2)*Cos*Sin);
    case 2222
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*(Q(w).^4*Sin^4-6*W(w).*Q(w).^2*Cos^2*Sin^2+W(w).^2*Cos^4);
    case 3122
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Cos.*(Q(w).^2*Sin^2+W(w)*(3*Sin^2-1)));
    case 3222
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Sin.*(Q(w).^2*Sin^2-3*W(w)*Cos^2));
    case 1322
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w).*(Q(w)*Cos.*(Q(w).^2*Sin^2+W(w)*(3*Sin^2-1))));
    case 2322
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w)).*(Q(w)*Sin.*(Q(w).^2*Sin^2-3*W(w)*Cos^2));
    case 3322
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(-Z(w)).*(xx(w).^2-1).*(Q(w).^2*Sin^2-W(w)*Cos^2);
    otherwise
end
%% 12����ƫ������
switch ori
    case 1112
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((W(w)+Q(w).^2).*(Q(w).^2*Cos^2-W(w)*Sin^2)*Sin*Cos+2*Q(w).^2.*W(w)*(Cos^2-Sin^2)*Cos*Sin);
    case {1212,2112}
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((Q(w).^2+W(w)).^2*Cos^2*Sin^2-Q(w).^2.*W(w)*(Cos^2-Sin^2)^2);
    case 2212
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(xx(w).^2+1).*((Q(w).^2+W(w)).*(Q(w).^2*Sin^2-W(w)*Cos^2)*Sin*Cos-2*W(w).*Q(w).^2*(Cos^2-Sin^2)*Cos*Sin);
    case 3112
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Sin.*(Q(w).^2*Cos^2+W(w)*(3*Cos^2-1)));
    case 3212
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(xx(w).^4-1).*(Q(w)*Cos.*(Q(w).^2*Sin^2+W(w)*(3*Sin^2-1)));
    case 1312
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w)).*(Q(w)*Sin.*(Q(w).^2*Cos^2+W(w)*(3*Cos^2-1)));
    case 2312
        y=@(w)2*(-1/8*A.^2./xx(w).^2).*(-Z(w).*(Q(w)*Cos.*(Q(w).^2*Sin^2+W(w)*(3*Sin^2-1))));
    case 3312
        y=@(w)2*(1/8*A.^2./xx(w).^2).*(-Z(w)).*(xx(w).^2-1).*(Q(w).^2+W(w))*Sin*Cos;
    otherwise
end
%% 13����ƫ����
switch ori
    case 1113
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Cos^2-3*(I1(w)+I2(w))*Sin^2)));
    case {1213,2113}
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Cos^2+(I1(w)+I2(w))*(3*Cos^2-1))));
    case 2213
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Sin^2+(I1(w)+I2(w))*(3*Sin^2-1))));
    case 3113
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(I1(w)*Cos^2-(I1(w)+I2(w))*Sin^2)));
    case 3213
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(2*I1(w)+I2(w))*Sin*Cos));
    case 1313
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Z(w).*(1./(xx(w).^2+1)).*(I1(w)*Cos^2-(I1(w)+I2(w))*Sin^2)));
    case 2313
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Z(w).*(1./(xx(w).^2+1)).*(2*I1(w)+I2(w))*Sin*Cos));
    case 3313
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*Z(w).*Q(w)*Cos));
    otherwise
end
%% 23����ƫ������
switch ori
    case 1123
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Cos^2+(I1(w)+I2(w))*(3*Cos^2-1))));
    case {1223,2123}
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Cos.*(I1(w)*Sin^2+(I1(w)+I2(w))*(3*Sin^2-1))));
    case 2223
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(Q(w)*Sin.*(I1(w)*Sin^2-3*(I1(w)+I2(w))*Cos^2)));
    case 3123
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*(2*I1(w)+I2(w))*Sin*Cos)); 
    case 3223
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(-1/4*A./xx(w)).*((xx(w).^2-1).*(I1(w)*Sin^2-(I1(w)+I2(w))*Cos^2)));
    case 1323
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(-1/4*A./xx(w)).*(-Z(w).*(1./(xx(w).^2+1)).*(2*I1(w)+I2(w))*Sin*Cos));
    case 2323
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(-1/4*A./xx(w)).*(-Z(w).*(1./(xx(w).^2+1)).*(I1(w)*Sin^2-(I1(w)+I2(w))*Cos^2)));
    case 3323
        y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(2*(1/4*A./xx(w)).*(-(xx(w).^2-1).*Z(w).*Q(w)*Sin));
    otherwise
end
%% 33����ƫ������
switch ori
    case 1133                                         
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(cos(2*phi)*I1(w)-sin(phi)^2*I2(w)));
    case {1233,2133}
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(2*sin(phi)*cos(phi)*I1(w)+sin(phi)*cos(phi)*I2(w)));
    case 2233
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(-cos(2*phi)*I1(w)-cos(phi)^2*I2(w)));
    case 3133
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*cos(phi)));
    case 3233
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(-((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar)).*(xx(w).^4-1)*sin(phi)));
    case 1333
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*((xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*cos(phi)));
    case 2333
    y=@(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*((xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*((z+zbar)*xx(w).^2-2*Tp/sqrt(k^2-1)*xx(w)+(z-zbar))*sin(phi)));
    case 3333
    y = @(w)-A*(xx(w).^2+1)./(2*xx(w)).*(-A*(xx(w).^2+1)./(2*xx(w)).*(-(xx(w).^4-2*(k^2+1)/(k^2-1)*xx(w).^2+1).*(xx(w).^2-1)));
end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
convert=@(w)(xx(w).^4-2/(k^2-1)*xx(w).^2+1).*(xx(w).^4-1);
y1=@(w)y(w).*convert(w)./(sqrt(1-tau^2*sin(w).^2).*sigma(w).*xx(w).^3);
result=A^2/(8*R*pi^2*sqrt(a*b1*c2))*real(integral(y1,0,pi/2));
end