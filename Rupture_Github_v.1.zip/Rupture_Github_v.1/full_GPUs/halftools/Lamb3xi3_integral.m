function derivation=Lamb3xi3_integral(x, h, t, vc, ori)%���x3��ƫ��
dx=0.0001;
derivation1=Lamb3_integral(x,h,t,vc,ori);
h=h+dx;
derivation2=Lamb3_integral(x,h,t,vc,ori);
derivation=(derivation2-derivation1)/dx;