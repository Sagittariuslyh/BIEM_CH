function derivation=Lamb3xi1_integral(x, h, t, vc, ori)%���x3��ƫ��
dx=0.0001;
derivation1=Lamb3_integral(x,h,t,vc,ori);
x(1)=x(1)+dx;
derivation2=Lamb3_integral(x,h,t,vc,ori);
derivation=-(derivation2-derivation1)/dx;