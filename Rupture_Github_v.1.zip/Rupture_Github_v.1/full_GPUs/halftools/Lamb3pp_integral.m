function result=Lamb3pp_integral(x, h, t, vc, ori)
%% The PP part of the Green function by Johnson(1974) equation (44)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1 = x(1);
x2 = x(2);
x3 = x(3);
R = sqrt(x1^2+x2^2);
r = sqrt(R^2+(x3+h)^2);  
theta = atan(R/(x3+h));
phi = atan(x2/x1);
alpha = vc(1);
beta = vc(2);
p1=sqrt(t.^2/r^2-1/alpha^2);
Tp = alpha*t/r;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(Tp < 1)
    result=0;
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=@(x)p1.*sin(x);
q=@(x)-t./r*sin(theta)+i*p1.*cos(x).*cos(theta);
eta1=@(x)sqrt(-q(x).^2+1/alpha^2+p(x).^2);
eta2=@(x)sqrt(-q(x).^2+1/beta^2+p(x).^2);
gamma=@(x)eta2(x).^2+p(x).^2-q(x).^2;
sigma=@(x)gamma(x).^2+4*eta1(x).*eta2(x).*(q(x).^2-p(x).^2);
sigmabar=@(x)gamma(x).^2-4*eta1(x).*eta2(x).*(q(x).^2-p(x).^2);

A20 = @(x)(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2);
A11 = @(x)(q(x).^2+p(x).^2)*cos(phi)*sin(phi);
A02 = @(x)(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2);
A30 = @(x)(q(x).^2*cos(phi)^2-3*p(x).^2*sin(phi)^2).*q(x)*cos(phi);
A21 = @(x)(q(x).^2*cos(phi)^2+p(x).^2*(3*cos(phi)^2-1)).*q(x)*sin(phi);
A12 = @(x)(q(x).^2*sin(phi)^2+p(x).^2*(3*sin(phi)^2-1)).*q(x)*cos(phi);
A03 = @(x)(q(x).^2*sin(phi)^2-3*p(x).^2*cos(phi)^2).*q(x)*sin(phi);
A40 = @(x)(q(x).^4*cos(phi)^4-6*q(x).^2.*p(x).^2*cos(phi)^2*sin(phi)^2+p(x).^4*sin(phi)^4);
A22 = @(x)(p(x).^2+q(x).^2).^2*cos(phi)^2*sin(phi)^2+...
     -p(x).^2.*q(x).^2*(cos(phi)^2-sin(phi)^2)^2;
A04 = @(x)(q(x).^4*sin(phi)^4-6*q(x).^2.*p(x).^2*cos(phi)^2*sin(phi)^2+p(x).^4*cos(phi)^4);
A31 = @(x)(p(x).^2+q(x).^2).*(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2)*sin(phi)*cos(phi)+...
     +2*p(x).^2.*q(x).^2*(cos(phi)^2-sin(phi)^2)*cos(phi)*sin(phi);
A13 = @(x)(p(x).^2+q(x).^2).*(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2)*sin(phi)*cos(phi)+...
     +2*p(x).^2.*q(x).^2*(sin(phi)^2-cos(phi)^2)*cos(phi)*sin(phi);
switch ori
    case 11
    y=@(x)-A20(x);
    case {12,21}
    y=@(x)-A11(x);
    case 22
    y=@(x)-A02(x);
    case 13
    y=@(x)-q(x).*eta1(x)*cos(phi);
    case 23
    y=@(x)-q(x).*eta1(x)*sin(phi);
    case 31
    y=@(x)q(x).*eta1(x)*cos(phi);
    case 32
    y=@(x)q(x).*eta1(x)*sin(phi);
    case 33
    y=@(x)eta1(x).^2;
    otherwise
end 
%% 1 ����ƫ����
switch ori
    case 111
    y = @(x)-A30(x);
    case {121,211}
    y = @(x)-A21(x);
    case 221
    y = @(x)-A12(x);
    case 2213
    y = @(x)eta1(x).*A12(x);
    case 131
    y = @(x)-eta1(x).*A20(x);
    case 1313
    y = @(x)eta1(x).^2.*A20(x);
    case 231
    y = @(x)-eta1(x).*A11(x);
    case 311
    y = @(x)eta1(x).*A20(x);
    case 321
    y = @(x)eta1(x).*A11(x);
    case 331
    y = @(x)eta1(x).^2.*q(x).*cos(phi);
    otherwise
end
%% 2 ����ƫ����
switch ori
    case 112
    y = @(x)-A21(x);
    case {122,212}
    y = @(x)-A12(x);
    case {1223,2123}
    y = @(x)eta1(x).*A12(x);
    case 222
    y = @(x)-A03(x);
    case 132
    y = @(x)-eta1(x).*A11(x);
    case 232
    y = @(x)-eta1(x).*A02(x);
    case 2323
    y = @(x)eta1(x).^2.*A02(x);
    case 312
    y = @(x)eta1(x).*A11(x);
    case 322
    y = @(x)eta1(x).*A02(x);
    case 3223
    y = @(x)-eta1(x).^2.*A02(x);
    case 332
    y = @(x)eta1(x).^2.*q(x).*sin(phi);
    otherwise
end
%% 3 ����ƫ����
switch ori
    case 113
    y=@(x)A20(x).*eta1(x);
    case {123,213}
    y=@(x)A11(x).*eta1(x);
    case 223
    y=@(x)A02(x).*eta1(x);
    case 133
    y=@(x)q(x).*eta1(x).^2*cos(phi);
    case 233
    y=@(x)q(x).*eta1(x).^2*sin(phi);
    case 313
    y=@(x)-q(x).*eta1(x).^2*cos(phi);
    case 323
    y=@(x)-q(x).*eta1(x).^2*sin(phi);
    case 333
    y=@(x)-eta1(x).^3;
    otherwise
end 
%% 11 ����ƫ����
switch ori
    case 1111
    y = @(x)-A40(x);
    case {1211,2111}
    y = @(x)-A31(x);
    case 2211
    y = @(x)-A22(x);
    case 1311
    y = @(x)-eta1(x).*A30(x);
    case 2311
    y = @(x)-eta1(x).*A21(x);
    case 3111
    y = @(x)eta1(x).*A30(x);
    case 3211
    y = @(x)eta1(x).*A21(x);
    case 3311
    y = @(x)eta1(x).^2.*A20(x);
    otherwise
end
%% 12 ����ƫ����
switch ori
    case 1112
    y = @(x)-A31(x);
    case {1212,2112}
    y = @(x)-A22(x);
    case 2212
    y = @(x)-A13(x);
    case 1312
    y = @(x)-eta1(x).*A21(x);
    case 2312
    y = @(x)-eta1(x).*A12(x);
    case 3112
    y = @(x)eta1(x).*A21(x);
    case 3212
    y = @(x)eta1(x).*A12(x);
    case 3312
    y = @(x)eta1(x).^2.*A11(x);
    otherwise
end
%% 13 ����ƫ����
switch ori
    case 1113
    y = @(x)eta1(x).*A30(x);
    case {1213,2113}
    y = @(x)eta1(x).*A21(x);
    case 2213
    y = @(x)eta1(x).*A12(x);
    case 1313
    y = @(x)eta1(x).*eta1(x).*A20(x);
    case 2313
    y = @(x)eta1(x).*eta1(x).*A11(x);
    case 3113
    y = @(x)-eta1(x).*eta1(x).*A20(x);
    case 3213
    y = @(x)-eta1(x).*eta1(x).*A11(x);
    case 3313
    y = @(x)-eta1(x).*eta1(x).^2.*q(x).*cos(phi);
    otherwise
end
%% 22 ����ƫ����
switch ori
    case 1122
    y = @(x)-A22(x);
    case {1222,2122}
    y = @(x)-A13(x);
    case 2222
    y = @(x)-A04(x);
    case 1322
    y = @(x)-eta1(x).*A12(x);
    case 2322
    y = @(x)-eta1(x).*A03(x);
    case 3122
    y = @(x)eta1(x).*A12(x);
    case 3222
    y = @(x)eta1(x).*A03(x);
    case 3322
    y = @(x)eta1(x).^2.*A02(x);
    otherwise
end
%% 23 ����ƫ����
switch ori
    case 1123
    y = @(x)eta1(x).*A21(x);
    case {1223,2123}
    y = @(x)eta1(x).*A12(x);
    case 2223
    y = @(x)eta1(x).*A03(x);
    case 1323
    y = @(x)eta1(x).*eta1(x).*A11(x);
    case 2323
    y = @(x)eta1(x).^2.*A02(x);
    case 3123
    y = @(x)-eta1(x).*eta1(x).*A11(x);
    case 3223
    y = @(x)-eta1(x).*eta1(x).*A02(x);
    case 3323
    y = @(x)-eta1(x).*eta1(x).^2.*q(x).*sin(phi);
    otherwise
end
%% 33 ����ƫ����
switch ori
    case 1133
    y=@(x)-A20(x).*eta1(x).^2;
    case {1233,2133}
    y=@(x)-A11(x).*eta1(x).^2;
    case 2233
    y=@(x)-A02(x).*eta1(x).^2;
    case 1333
    y=@(x)-q(x).*eta1(x).^3*cos(phi);
    case 2333
    y=@(x)-q(x).*eta1(x).^3*sin(phi);
    case 3133
    y=@(x)q(x).*eta1(x).^3*cos(phi);
    case 3233
    y=@(x)q(x).*eta1(x).^3*sin(phi);
    case 3333
    y=@(x)eta1(x).^4;
    otherwise
end 
y1=@(x)sigmabar(x).*y(x)./sigma(x);
result=1/(2*pi^2*r)*real(integral(y1,0,pi/2));
end  









