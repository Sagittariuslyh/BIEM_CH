function result=Lamb3_integral(x, h, t, vc, ori)
% dp = Lamb3dp_close(x, h, t, vc, ori);
% ds = Lamb3ds_close(x, h, t, vc, ori);
pp = Lamb3pp_integral(x, h, t, vc, ori);
ss = Lamb3ss_integral(x, h, t, vc, ori);
ps = Lamb3ps_integral(x, h, t, vc, ori);
sp = Lamb3sp_integral(x, h, t, vc, ori);
result=pp+ss+ps+sp;
end