function result=Lamb3ss3_integral(x, h, t, vc, ori)
%The SS part of the Green function by Johnson(1974) equation (48)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1=x(1);
x2=x(2);
x3=x(3);
alpha=vc(1);
beta=vc(2);
R=sqrt(x1^2+x2^2);
r=sqrt(R^2+(x3+h)^2);  
theta=atan(R/(x3+h));
phi=atan(x2/x1);
t1=r/alpha*sin(theta)+sqrt(1/beta^2-1/alpha^2)*r*cos(theta);
p1=sqrt(t^2/r^2-1/beta^2);
p2=sqrt((t/r-sqrt(1/beta^2-1/alpha^2)*cos(theta))^2/sin(theta)^2-1/alpha^2);
if(sin(theta)<beta/alpha)
    result=0;
elseif(t>r/beta)
    result=0;
elseif(t<t1)
    result=0;
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p=@(x)x;
q=@(x)-t/r*sin(theta)+sqrt(-p1^2+p(x).^2)*cos(theta);
eta1=@(x)sqrt(-q(x).^2+1/alpha^2+p(x).^2);
eta2=@(x)t/r*cos(theta)+sqrt(-p1^2+p(x).^2)*sin(theta);
gamma=@(x)eta2(x).^2+p(x).^2-q(x).^2;
sigma=@(x)gamma(x).^2+4*eta1(x).*eta2(x).*(q(x).^2-p(x).^2);
sigmabar=@(x)gamma(x).^2-4*eta1(x).*eta2(x).*(q(x).^2-p(x).^2);
A20 = @(x)(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2);
A11 = @(x)(q(x).^2+p(x).^2)*cos(phi)*sin(phi);
A02 = @(x)(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2);
A30 = @(x)(q(x).^2*cos(phi)^2-3*p(x).^2*sin(phi)^2).*q(x)*cos(phi);
A21 = @(x)(q(x).^2*cos(phi)^2+p(x).^2*(3*cos(phi)^2-1)).*q(x)*sin(phi);
A12 = @(x)(q(x).^2*sin(phi)^2+p(x).^2*(3*sin(phi)^2-1)).*q(x)*cos(phi);
A03 = @(x)(q(x).^2*sin(phi)^2-3*p(x).^2*cos(phi)^2).*q(x)*sin(phi);
A40 = @(x)(q(x).^4*cos(phi)^4-6*q(x).^2.*p(x).^2*cos(phi)^2*sin(phi)^2+p(x).^4*sin(phi)^4);
A22 = @(x)(p(x).^2+q(x).^2).^2*cos(phi)^2*sin(phi)^2+...
     -p(x).^2.*q(x).^2*(cos(phi)^2-sin(phi)^2)^2;
A04 = @(x)(q(x).^4*sin(phi)^4-6*q(x).^2.*p(x).^2*cos(phi)^2*sin(phi)^2+p(x).^4*cos(phi)^4);
A31 = @(x)(p(x).^2+q(x).^2).*(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2)*sin(phi)*cos(phi)+...
     +2*p(x).^2.*q(x).^2*(cos(phi)^2-sin(phi)^2)*cos(phi)*sin(phi);
A13 = @(x)(p(x).^2+q(x).^2).*(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2)*sin(phi)*cos(phi)+...
     +2*p(x).^2.*q(x).^2*(sin(phi)^2-cos(phi)^2)*cos(phi)*sin(phi);
switch ori
    case 11                                              
    y=@(x)-sigmabar(x).*(q(x).^2*cos(phi)^2-p(x).^2*sin(phi)^2)+beta^(-2)*(gamma(x).^2-4*eta1(x).*eta2(x).*(q(x).^2+p(x).^2)*(2*cos(phi)^2-1));
    case {12,21}
    y=@(x)-(q(x).^2+p(x).^2).*(sigmabar(x)+8*beta^(-2)*eta1(x).*eta2(x)).*sin(phi)*cos(phi);
    case 22
    y=@(x)-sigmabar(x).*(q(x).^2*sin(phi)^2-p(x).^2*cos(phi)^2)+beta^(-2)*(gamma(x).^2-4*eta1(x).*eta2(x).*(q(x).^2+p(x).^2)*(2*sin(phi)^2-1));
    case 13
    y=@(x)-sigmabar(x).*q(x).*eta2(x)*cos(phi);
    case 23
    y=@(x)-sigmabar(x).*q(x).*eta2(x)*sin(phi);
    case 31
    y=@(x)sigmabar(x).*q(x).*eta2(x)*cos(phi);
    case 32
    y=@(x)sigmabar(x).*q(x).*eta2(x)*sin(phi);
    case 33
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2); 
    otherwise
end 
%% 1 ������
switch ori
    case 111                                              
    y=@(x)beta^(-2)*sigma(x).*q(x)*cos(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A30(x);
    case {121,211}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A21(x);
    case 221
    y=@(x)beta^(-2)*sigma(x).*q(x)*cos(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x);
    case 2213
    y=@(x)-beta^(-2)*sigma(x).*q(x)*cos(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x).*eta2(x);
    case 131
    y=@(x)-sigmabar(x).*A20(x).*eta2(x);
    case 1313
    y=@(x)sigmabar(x).*A20(x).*eta2(x).^2;
    case 231
    y=@(x)-sigmabar(x).*A11(x).*eta2(x);
    case 311
    y=@(x)sigmabar(x).*A20(x).*eta2(x);
    case 321
    y=@(x)sigmabar(x).*A11(x).*eta2(x);
    case 331
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*q(x)*cos(phi); 
    otherwise
end 
%% 2 ������
switch ori
    case 112                                              
    y=@(x)beta^(-2)*sigma(x).*q(x)*sin(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A21(x);
    case {122,212}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x);
    case {1223,2123}
    y=@(x)(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x).*eta2(x);
    case 222
    y=@(x)beta^(-2)*sigma(x).*q(x)*sin(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A03(x);
    case 132
    y=@(x)-sigmabar(x).*A11(x).*eta2(x);
    case 232
    y=@(x)-sigmabar(x).*A02(x).*eta2(x);
    case 2323
    y=@(x)-sigmabar(x).*A02(x).*eta2(x).^2;
    case 312
    y=@(x)sigmabar(x).*A11(x).*eta2(x);
    case 322
    y=@(x)sigmabar(x).*A02(x).*eta2(x);
    case 3223
    y=@(x)-sigmabar(x).*A02(x).*eta2(x).^2;
    case 332
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*q(x)*sin(phi); 
    otherwise
end 
%% 3 ������
switch ori
    case 113                                             
    y=@(x)-beta^(-2)*sigma(x).*eta2(x)+(sigma(x)+8*eta1(x).*eta2(x).^3).*A20(x).*eta2(x);
    case {123,213}
    y=@(x)(sigma(x)+8*eta1(x).*eta2(x).^3).*A11(x).*eta2(x);
    case 223
    y=@(x)-beta^(-2)*sigma(x).*eta2(x)+(sigma(x)+8*eta1(x).*eta2(x).^3).*A02(x).*eta2(x);
    case 133
    y=@(x)sigmabar(x).*q(x).*eta2(x).^2*cos(phi);
    case 233
    y=@(x)sigmabar(x).*q(x).*eta2(x).^2*sin(phi);
    case 313
    y=@(x)-sigmabar(x).*q(x).*eta2(x).^2*cos(phi);
    case 323
    y=@(x)-sigmabar(x).*q(x).*eta2(x).^2*sin(phi);
    case 333
    y=@(x)sigmabar(x).*(q(x).^2-p(x).^2).*eta2(x); 
    otherwise
end 
%% 11 ������
switch ori
    case 1111                                              
    y=@(x)beta^(-2)*sigma(x).*A20(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A40(x);
    case {1211,2111}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A31(x);
    case 2211
    y=@(x)beta^(-2)*sigma(x).*A20(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A22(x);
    case 1311
    y=@(x)-sigmabar(x).*A30(x).*eta2(x);
    case 2311
    y=@(x)-sigmabar(x).*A21(x).*eta2(x);
    case 3111
    y=@(x)sigmabar(x).*A30(x).*eta2(x);
    case 3211
    y=@(x)sigmabar(x).*A21(x).*eta2(x);
    case 3311
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*A20(x); 
    otherwise
end 
%% 12 ������
switch ori
    case 1112                                              
    y=@(x)beta^(-2)*sigma(x).*A11(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A31(x);
    case {1212,2112}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A22(x);
    case 2212
    y=@(x)beta^(-2)*sigma(x).*A11(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A13(x);
    case 1312
    y=@(x)-sigmabar(x).*A21(x).*eta2(x);
    case 2312
    y=@(x)-sigmabar(x).*A12(x).*eta2(x);
    case 3112
    y=@(x)sigmabar(x).*A21(x).*eta2(x);
    case 3212
    y=@(x)sigmabar(x).*A12(x).*eta2(x);
    case 3312
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*A11(x); 
    otherwise
end 
%% 22 ������
switch ori
    case 1122                                              
    y=@(x)beta^(-2)*sigma(x).*A02(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A22(x);
    case {1222,2122}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A13(x);
    case 2222
    y=@(x)beta^(-2)*sigma(x).*A02(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A04(x);
    case 1322
    y=@(x)-sigmabar(x).*A12(x).*eta2(x);
    case 2322
    y=@(x)-sigmabar(x).*A03(x).*eta2(x);
    case 3122
    y=@(x)sigmabar(x).*A12(x).*eta2(x);
    case 3222
    y=@(x)sigmabar(x).*A03(x).*eta2(x);
    case 3322
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*A02(x); 
    otherwise
end 
%% 13 ������
switch ori
    case 1113                                              
    y=@(x)-(beta^(-2)*sigma(x).*q(x)*cos(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A30(x)).*eta2(x);
    case {1213,2113}
    y=@(x)(sigma(x)+8*eta1(x).*eta2(x).^3).*A21(x).*eta2(x);
    case 2213
    y=@(x)-(beta^(-2)*sigma(x).*q(x)*cos(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x)).*eta2(x);
    case 1313
    y=@(x)sigmabar(x).*A20(x).*eta2(x).*eta2(x);
    case 2313
    y=@(x)sigmabar(x).*A11(x).*eta2(x).*eta2(x);
    case 3113
    y=@(x)-sigmabar(x).*A20(x).*eta2(x).*eta2(x);
    case 3213
    y=@(x)-sigmabar(x).*A11(x).*eta2(x).*eta2(x);
    case 3313
    y=@(x)sigmabar(x).*(q(x).^2-p(x).^2).*q(x)*cos(phi).*eta2(x); 
    otherwise
end 
%% 23 ������
switch ori
    case 1123                                            
    y=@(x)(beta^(-2)*sigma(x).*q(x)*sin(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A21(x)).*(-eta2(x));
    case {1223,2123}
    y=@(x)(sigma(x)+8*eta1(x).*eta2(x).^3).*A12(x).*eta2(x);
    case 2223
    y=@(x)-(beta^(-2)*sigma(x).*q(x)*sin(phi)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A03(x)).*eta2(x);
    case 1323
    y=@(x)sigmabar(x).*A11(x).*eta2(x).*eta2(x);
    case 2323
    y=@(x)sigmabar(x).*A02(x).*eta2(x).*eta2(x);
    case 3123
    y=@(x)-sigmabar(x).*A11(x).*eta2(x).*eta2(x);
    case 3223
    y=@(x)-sigmabar(x).*A02(x).*eta2(x).*eta2(x);
    case 3323
    y=@(x)sigmabar(x).*(q(x).^2-p(x).^2).*q(x)*sin(phi).*eta2(x); 
    otherwise
end 
%% 33 ������
switch ori
    case 1133                                              
    y=@(x)beta^(-2)*sigma(x).*eta2(x).^2-(sigma(x)+8*eta1(x).*eta2(x).^3).*A20(x).*eta2(x).^2;
    case {1233,2133}
    y=@(x)-(sigma(x)+8*eta1(x).*eta2(x).^3).*A11(x).*eta2(x).^2;
    case 2233
    y=@(x)beta^(-2)*sigma(x).*eta2(x).^2-(sigma(x)+8*eta1(x).*eta2(x).^3).*A02(x).*eta2(x).^2;
    case 1333
    y=@(x)-sigmabar(x).*q(x).*eta2(x).^3*cos(phi);
    case 2333
    y=@(x)-sigmabar(x).*q(x).*eta2(x).^3*sin(phi);
    case 3133
    y=@(x)sigmabar(x).*q(x).*eta2(x).^3*cos(phi);
    case 3233
    y=@(x)sigmabar(x).*q(x).*eta2(x).^3*sin(phi);
    case 3333
    y=@(x)-sigmabar(x).*(q(x).^2-p(x).^2).*eta2(x).^2; 
    otherwise
end 
y1=@(x)y(x)./(sigma(x).*sqrt(p(x).^2-p1^2));
result=-1/(2*pi^2*r)*imag(integral(y1,0,p2));
end