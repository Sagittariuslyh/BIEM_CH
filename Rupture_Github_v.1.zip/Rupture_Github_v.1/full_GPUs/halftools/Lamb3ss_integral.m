function result=Lamb3ss_integral(x, h, t, vc, ori)
%The SS part of the Green function by Johnson(1974) equation (48)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
result=Lamb3ss1_integral(x, h, t, vc, ori)+Lamb3ss2_integral(x, h, t, vc, ori)+Lamb3ss3_integral(x, h, t, vc, ori);