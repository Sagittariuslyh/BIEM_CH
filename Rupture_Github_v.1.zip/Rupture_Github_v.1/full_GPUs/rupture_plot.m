% 用于绘制破裂过程rate时空变化的gif

clc
clear

%% 导入数据：网格信息及rate（如果需要画slip或者stress对应修改即可）
load('point.mat');
load('triangle.mat');
load('rate.mat')

% rate=stress;

%% 迭代画图（画图时间会随帧数增加变长）
stepnum = length(rate(1,:)); % 总帧数：总时间步数
pic_num = 1;

for k = 1:3:stepnum % 每三帧画一幅图
% 画当前时间步图像
    cla; % 清空上一个时间步的图像（防止重叠）
    cdata = rate(:,k);
    patch('Faces',t(:,1:3),'Vertices',p,'FaceColor','flat','FaceVertexCData',cdata,'CDataMapping','scaled');
    colorbar('position',[0.925,0.1,0.02,0.8],'FontSize',16);
%     caxis([0,15]) % colorbar范围
    axis([min(p(:,1)) max(p(:,1)) min(p(:,2)) max(p(:,2)) 0 1]);
    axis equal; 
    text(23.2,11.3,num2str(k*0.05,'%.2f s'),'FontName','Times New Roman','FontSize',20);
    xlabel('Strike/km','position',[25,-3,0])
    ylabel('Dip/km','position',[-3.5,5,0])
    text(13.5,13.5,'Fluid-saturated Ruhr Sandstone','FontName','Times New Roman','FontSize',24)
    text(51.0,15.8,'m/s','FontName','Times New Roman','FontSize',20)
    set(gcf,'position',[400,400,800,300])
    set(gca,'FontName','Times New Roman','FontSize',20)
    drawnow;
%     view([0,-44]);
% 绘制gif代码
    F = getframe(gcf);
    I = frame2im(F);
    [I,map] = rgb2ind(I,256);

    if pic_num == 1
        imwrite(I,map,'存储的文件名.gif','gif','Loopcount',inf,'Delaytime',0.05);
    else
        imwrite(I,map,'存储的文件名.gif','gif','WriteMode','append','Delaytime',0.05);
    end

    pic_num = pic_num+1;
end