#!/bin/bash
export PATH=/data/home/scv8091/run/matlab2019-install/bin:$PATH
matlab -nodesktop -nosplash -r "run('mainGPUs_singletask.m');" -logfile xxx.log
