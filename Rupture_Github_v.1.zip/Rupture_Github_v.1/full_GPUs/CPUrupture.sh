#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
export PATH=/public3/home/scb9633/software-scb9633/matlab2017b/matlab-install/bin:$PATH
matlab < mainfullmatrix.m
