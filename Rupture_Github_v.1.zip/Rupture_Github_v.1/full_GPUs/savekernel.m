% 用于组合Kernel
load('Knmt311_1_full.mat');
load('Knmt331_1_full.mat');
load('Knmt311_1_half.mat');
load('Knmt331_1_half.mat');

kernel_T=kernel_T_half+kernel_T_full;
kernel_N=kernel_N_half+kernel_N_full;

save('Knmt311_1.mat','kernel_T','-v7.3')
save('Knmt331_1.mat','kernel_N','-v7.3')