clear
clc

addpath('tools')

%% 读取数据
fileID = fopen('Rupture_Input.txt', 'r');
lineNumber = 1;

data = []; % 创建一个空数组来存储数据

while ~feof(fileID)
    line = fgetl(fileID); % 逐行读取
    if ischar(line)
        line = strtrim(strtok(line, '%'));
        % 将每行数据转换为数字
        value = str2double(line);
        
        if ~isnan(value)
            % 将每行数据存储在数组中
            data(lineNumber) = value;
            lineNumber = lineNumber + 1;
        end
    end
end

fclose(fileID);

ngpu=data(1);

%% 主程序
parpool(ngpu);

load('point.mat');
load('triangle.mat');
load('Knmt311_1_full.mat');
load('Knmt331_1_full.mat');

kernel_N=kernel_N_full;
kernel_T=kernel_T_full;
kernel_N=permute(kernel_N_full,[1,3,2]);
kernel_T=permute(kernel_T_full,[1,3,2]);

T=size(t,1);
maxtime=size(kernel_T,2)-1;

scale=1;%实际网格尺寸/现有网格尺寸
det_s=data(2); %因为不同的弯折角度的det_s不一样，所以统一起来
MinR=det_s*scale;
ct=data(4);cl=data(3);
mu=data(5)*ct*ct;
CFL=data(6);
det_t=CFL*MinR/cl;

mus=data(7);
mud=data(8);
mu0=mus-mud;

GPUkernel_T=Composite();
GPUkernel_N=Composite();
GPUrate=Composite();
subN=floor(T/ngpu);
over=0;
for i=1:ngpu
    start=over+1;
    over=start+subN-1;
    if i<=mod(T,ngpu)
        over=over+1;
    end     
    GPUkernel_T{i}=gpuArray(kernel_T(start:over,:,:));
    GPUkernel_N{i}=gpuArray(kernel_N(start:over,:,:));
end
%%
mkdir('output');
alpha2=t(:,4)+pi/2;
N3_1=data(9)*ones(T,1);
N1_1=data(10)*ones(T,1);
T31_1=data(11);

if data(17)==2
    N3_2=(N3_1+N1_1)/2+(N1_1-N3_1).*cos(2*alpha2)/2+T31_1.*sin(2*alpha2);
    T31_2=(N1_1-N3_1).*sin(2*alpha2)/2-T31_1.*cos(2*alpha2);
elseif data(17)==1
    N3_2=data(9).*(1-2.*(abs(heaviside(t(:,4))-0.5)))+data(18).*2.*abs(heaviside(t(:,4))-0.5);
    T31_2=data(11).*(1-2.*(abs(heaviside(t(:,4))-0.5)))+data(19).*2.*abs(heaviside(t(:,4))-0.5);
end
N0=-N3_2;


stress0=T31_2;
stress0(T31_2>0.99*mus*(-N3_2))=0.99*mus*(-N3_2(T31_2>0.99*mus*(-N3_2)));

N3_1=abs(N3_1);
N1_1=abs(N1_1);

Tu0=mus*N3_1;
pi2=2*pi;
fd=2*Tu0*(3*MinR)/mu;
fv=2*Tu0*ct/mu;
Ti=data(12)*Tu0;
D0=2*fd;
fp0=mu/(2*ct)-(Tu0./D0)*det_t;

stress=zeros(T,maxtime);
rate=zeros(T,maxtime);
slip=zeros(T,maxtime);
flag=zeros(T,1);
N=zeros(T,maxtime);
Dc_num=0.5; % Dc
Dc=data(13).*ones(T,1);%Dc_num*D0.*ones(T,1);

nuc_radius=data(16);
nuc_x0=data(14);
nuc_y0=data(15);
t_nucleation=get_nucleation(p,t,nuc_radius,nuc_x0,nuc_y0);
stress0(t_nucleation(:))=Ti(t_nucleation(:));
rate(t_nucleation(:),1)=(stress0(t_nucleation(:))-mus*N0(t_nucleation(:)))./fp0(t_nucleation(:));
stress(:,1)=stress0;
N(:,1)=N0;

tic;
parfor_progress(maxtime-1);
for k=2:maxtime
%     disp(k);
    over=0;
    for i=1:ngpu
        start=over+1;
        over=start+subN-1;
        if i<=mod(T,ngpu)
            over=over+1;
        end
        GPUrate{i}=gpuArray(rate(start:over,1:k-1));
    end
    
    if k==2
        spmd(ngpu)
            sum1_all_T=sum(bsxfun(@times,GPUkernel_T(:,k:-1:2,:),GPUrate));
            sum1_all_N=sum(bsxfun(@times,GPUkernel_N(:,k:-1:2,:),GPUrate));
        end
        sum2=rate(:,1);
        sumT_Struct=gplus(gather(sum1_all_T));
        sumN_Struct=gplus(gather(sum1_all_N));
        sum1_all_N=0;
        sum1_all_T=0;
        for i=1:ngpu
            sum1_all_T=sum1_all_T+sumT_Struct{i};
            sum1_all_N=sum1_all_N+sumN_Struct{i};
        end
    else
        spmd(ngpu)
            sum1_all_T=sum(sum(bsxfun(@times,GPUkernel_T(:,k:-1:2,:),GPUrate)));
            sum1_all_N=sum(sum(bsxfun(@times,GPUkernel_N(:,k:-1:2,:),GPUrate)));
        end
        sumT_Struct=gplus(gather(sum1_all_T));
        sumN_Struct=gplus(gather(sum1_all_N));
        sum1_all_N=0;
        sum1_all_T=0;
        for i=1:ngpu
            sum1_all_T=sum1_all_T+sumT_Struct{i};
            sum1_all_N=sum1_all_N+sumN_Struct{i};
        end
        sum2=sum(rate(:,1:k-1),2); 
    end
    sum1_T=permute(gather(sum1_all_T),[3 1 2]);
    sum1_N=permute(gather(sum1_all_N),[3 1 2]);

    N(:,k)=N0-sum1_N;
           
    temp_T=sum1_T+stress0;
    temp=temp_T-mus.*N(:,k);
    temp_N=mu0.*(1-sum2.*det_t./Dc).*N(:,k);
    temp_d=mud.*N(:,k);
    fp=mu/(2*ct)-(mu0.*N(:,k)./Dc).*det_t;
    
    rate(:,k)=(temp_T-temp_N-temp_d)./fp;
    slip(rate(:,k)<0,k)=det_t.*(sum2(rate(:,k)<0)+rate(rate(:,k)<0,k));
    stress(rate(:,k)<0,k)=temp_T(rate(:,k)<0);
    rate(rate(:,k)<0,k)=0;
    flag(rate(:,k)>0)=1;
    slip(rate(:,k)>0,k)=det_t.*(sum2(rate(:,k)>0)+rate(rate(:,k)>0,k));
    stress(rate(:,k)>0,k)=(mu0.*(1-slip(rate(:,k)>0,k)./Dc(rate(:,k)>0))+mud).*N(rate(:,k)>0,k);
    
    stress(slip(:,k)>=Dc,k)=mud.*N(slip(:,k)>=Dc,k);
    rate(slip(:,k)>=Dc,k)=(temp_T(slip(:,k)>=Dc)-temp_d(slip(:,k)>=Dc))./(mu/(2*ct));
    stress(rate(:,k)<0,k)=temp_T(rate(:,k)<0);
    rate(rate(:,k)<0,k)=0;
    slip(slip(:,k)>=Dc&rate(:,k)>0,k)=det_t.*(rate(slip(:,k)>=Dc&rate(:,k)>0,k)+sum2(slip(:,k)>=Dc&rate(:,k)>0));
    parfor_progress;
end
parfor_progress(0);
toc;
if data(17)==2
    fname=['Dc=',num2str(data(13)*1000),'_mus=',num2str(mus),'_mud=',num2str(mud),'_Te=',num2str(data(11)),'_N3=',num2str(data(9)),'_N1_=',num2str(data(10))];
elseif data(17)==1
    fname=['Dc=',num2str(data(13)*1000),'_mus=',num2str(mus),'_mud=',num2str(mud),'_Te=',num2str(data(11)),'_N3=',num2str(data(9)),'_N3_2_=',num2str(data(18)),'_T31_2_=',num2str(data(19))];
end

mkdir(fname);
save([fname,'/slip.mat'],'slip');
save([fname,'/rate.mat'],'rate');
save([fname,'/stress.mat'],'stress');
save([fname,'/N.mat'],'N');
