clc
clear

type='unstructed';

load('triangle.mat');
load('point.mat');
% p(:,3)=0;

% temp=p(:,3);
% p(:,3)=p(:,2);
% p(:,2)=temp;
T1=size(t,1);
cdata1=ones(T1,1);
switch type
    case 'unstructed'
        patch('Faces',t(:,1:3),'Vertices',p(:,1:3),'FaceColor',[0.85,0.85,0.85],'FaceVertexCData',cdata1,'CDataMapping','scaled');drawnow
    case 'structed'
        patch('Faces',t(:,1:4),'Vertices',p(:,1:3),'FaceColor',[0.85,0.85,0.85],'FaceVertexCData',cdata1,'CDataMapping','scaled');drawnow
    otherwise
end

% axis([min(p(:,1)) max(p(:,1)) min(p(:,2)) max(p(:,2)) min(p(:,3)) max(p(:,3))]);
% set(gca,'YDir','reverse');
% set(gca,'ZDir','reverse');
% view([-10,30]);
% axis off

% 个别单元绘制
switch type
    case 'unstructed'
        patch('Faces',t(1,1:3),'Vertices',p(:,1:3),'FaceColor',[0,0.85,0.85],'FaceVertexCData',cdata1,'CDataMapping','scaled');drawnow
        patch('Faces',t(397,1:3),'Vertices',p(:,1:3),'FaceColor',[0.85,0,0.85],'FaceVertexCData',cdata1,'CDataMapping','scaled');drawnow
    case 'structed'
        patch('Faces',t(:,1:4),'Vertices',p(:,1:3),'FaceColor',[0.85,0.85,0.85],'FaceVertexCData',cdata1,'CDataMapping','scaled');drawnow
    otherwise
end
legend('background','source','receive')
%%%%%%%%%%%%%%%%%%%%

% axis([min(p(:,1)) max(p(:,1)) min(p(:,2)) max(p(:,2)) 0 1]);
axis equal;
xlabel('\it{x}\rm{_1/km}','FontName','Times New Roman','Fontsize',16,'Position',[15,17.5]);
ylabel('\it{x}\rm{_3/km}','FontName','Times New Roman','Fontsize',16,'Position',[-1.8,7.5]);

set(gcf,'Position',[600 600 560 350])

zlabel('\it{x}\rm{_2/km}','FontName','Times New Roman','Fontsize',16,'Rotation',0,'Position',[-2.6,-1]);
set(gca,'FontSize',16);
set(gca,'YDir','reverse');
set(gca,'ZTick',[0,2]);
set(gca,'FontName','Times New Roman','Fontsize',16)