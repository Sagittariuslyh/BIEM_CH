% function []=meshplane_structed(node1,node2,node3,node4,dimension)
% node的四个点顺时针或逆时针依次排列即可
% node1的xy坐标建议均为0
clear
clc

addpath([fileparts(pwd),'/toolkit']);
node1=[-15,0,0];
node2=[15,0,0];
node3=[15,15,0];
node4=[-15,15,0];
dimension=0.5;

%% 调整参数
vector1=node2-node1;
vector2=node4-node1;
p_len=norm(vector1); % 断层长
p_wid=norm(vector2); % 断层宽
p_size=dimension; % 正方形单元尺寸（边长）

%% 绘制网格
Ln=round(p_len/p_size);
Lm=round(p_wid/p_size);
p=zeros((Ln+1)*(Lm+1),3);
t=zeros(Ln*Lm,5);
p(:,3)=0; % 平面断层
t(:,5)=0;
num=0; % 标记网格序号
for i=1:Ln
    for j=1:Lm
        num=num+1;
        A=[(i-1)*p_size,(j-1)*p_size];
        B=[(i-1)*p_size,j*p_size];
        C=[i*p_size,j*p_size];
        D=[i*p_size,(j-1)*p_size];
        for k=1:2
            p(round((i-1)*(Lm+1)+j),k)=A(k);
            p(round((i-1)*(Lm+1)+j+1),k)=B(k);
            p(round(i*(Lm+1)+j+1),k)=C(k);
            p(round(i*(Lm+1)+j),k)=D(k);
        end
        t((i-1)*Lm+j,1)=round((i-1)*(Lm+1)+j);
        t((i-1)*Lm+j,2)=round((i-1)*(Lm+1)+j+1);
        t((i-1)*Lm+j,3)=round(i*(Lm+1)+j+1);
        t((i-1)*Lm+j,4)=round(i*(Lm+1)+j);
    end
end

%% 保存为txt文件
% 指定要保存的文件名
filename1 = 'point.txt';
filename2 = 'triangle.txt';

% 打开文件进行写操作
fileID = fopen(filename1, 'w');
% 循环遍历数组并将浮点数写入文件
[m, n] = size(p); % 获取数组的大小
fprintf(fileID, '%d',m);
fprintf(fileID, ' ');
fprintf(fileID, '%d',n);
fprintf(fileID, '\n');
for i = 1:m
    for j = 1:n
        fprintf(fileID, '%f', p(i, j)); % 写入当前元素的值
        if j < n
            fprintf(fileID, ' '); % 使用逗号分隔
        else
            fprintf(fileID, '\n'); % 换行
        end
    end
end
% 打开文件进行写操作
fileID = fopen(filename2, 'w');
% 循环遍历数组并将浮点数写入文件
[m, n] = size(t); % 获取数组的大小
fprintf(fileID, '%d',m);
fprintf(fileID, ' ');
fprintf(fileID, '%d',n);
fprintf(fileID, '\n');
for i = 1:m
    for j = 1:n
        fprintf(fileID, '%f', t(i, j)); % 写入当前元素的值
        if j < n
            fprintf(fileID, ' '); % 使用逗号分隔
        else
            fprintf(fileID, '\n'); % 换行
        end
    end
end

%% 保存网格
save point.mat p;
save triangle.mat t;
simpplot(p,t(:,1:4));

% xlabel('x1')
% ylabel('x2')
% zlabel('x3')