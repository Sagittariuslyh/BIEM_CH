clc
clear

load('triangle.mat');
load('point.mat');

%% 调整参数
deep=0.3;
dz=0.2;

%% 获取网格
n=size(t,1); % 三角形网格数
t_inner=get_inner(p,t); % 获取三角形单元内心坐标
t_line=find(t_inner(:,2)<deep+dz&t_inner(:,2)>deep-dz); % 第二个坐标对应深度
t_line(:,2)=t_inner(t_line(:),1);
t_line=sortrows(t_line,2);
fname=['t_line_',num2str(n)];
save(fname,'t_line');