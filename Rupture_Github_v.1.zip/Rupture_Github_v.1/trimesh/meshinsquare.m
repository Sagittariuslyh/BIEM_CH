clc
clear

%% 本程序生成p的坐标依次是：走向坐标，垂向坐标（向下为正），垂直走向坐标

addpath([fileparts(pwd),'/toolkit']);

%% 调整参数
p_len=3; % 断层面长
p_wid=1.5; % 断层面宽
p_size=0.05; % 断层面三角形网格尺寸
p1_len=0.3; % 矩形区域长
p1_wid=0.3; % 矩形区域宽
p1_size=0.05; % 矩形区域三角形网格尺寸

%% 计算网格坐标
fd=@(p) drectangle(p,-p1_len/2+p_len/2,p1_len/2+p_len/2,-p1_wid/2+p_wid/2,p1_wid/2+p_wid/2);
[p,t]=distmesh2d(fd,@huniform,p1_size,[0,0;p_len,p_wid],[-p1_len/2+p_len/2,-p1_wid/2+p_wid/2;-p1_len/2+p_len/2,p1_wid+p_wid/2;p1_len/2+p_len/2,-p1_wid/2+p_wid/2;p1_len/2+p_len/2,p1_wid+p_wid/2]);
simpplot(p,t(:,1:3));
s=get_side(t);
[s_t,s_bound]=get_s_t(s,t);
[p_bound,p_bound_point]=bound_point(s_bound,p,s);
fd=@(p) drectangle(p,0,p_len,0,p_wid);
pv=[p_bound_point;0,-p_wid/2;0,p_wid;p_len,0;p_len,p_wid;];
[p,t]=distmesh2d(fd,@huniform,p_size,[0,0;p_len,p_wid],pv);
t(:,4)=0;

%% 中间有矩形区域的平面网格
save point.mat p;
save triangle.mat t;
simpplot(p,t(:,1:3));