%%�˽ű����ڰ����۶ϲ�����۴����������ƽ��
clear
clc

addpath([fileparts(pwd),'/toolkit']);

load point.mat;
load triangle.mat;

R=30; %RΪ��ƽ��ĳ���
alpha=40/180*pi; %���۽Ƕ�
alp=alpha/2;
a=1; %���۴���ƽ���Ķϲ㳤��

r=a/tan(alp); %���۴�ƽ���Ļ��Ȱ뾶
L=a/sin(alp); %���۵㵽Բ��Բ�ĳ���
pold=p;

for i=1:length(p(:,1))
    if pold(i,1)>R && pold(i,1)<R+a*cos(alpha)
        x0=p(i,1);
        y0=p(i,3);
        x1=x0-R;
        y1=y0;
        x2=x1*cos(alp)+y1*sin(alp);
        y2=y1*cos(alp)-x1*sin(alp);
        theta=alp-atan((a-sqrt(x2^2+y2^2))/r);
        xx=r*sin(theta);
        yy=L-r*cos(theta);
        xx1=xx*cos(-alp)+yy*sin(-alp);
        yy1=yy*cos(-alp)-xx*sin(-alp);
        xx0=xx1+R;
        yy0=yy1;
        p(i,1)=xx0;
        p(i,3)=yy0;
    end
    if pold(i,1)>R-a && pold(i,1)<=R
        x0=p(i,1);
        y0=p(i,3);
        x1=x0-R;
        y1=y0;
        x2=x1*cos(alp)+y1*sin(alp);
        y2=y1*cos(alp)-x1*sin(alp);
        theta=alp-atan((a-sqrt(x2^2+y2^2))/r);
        theta=-theta;
        xx=r*sin(theta);
        yy=L-r*cos(theta);
        xx1=xx*cos(-alp)+yy*sin(-alp);
        yy1=yy*cos(-alp)-xx*sin(-alp);
        xx0=xx1+R;
        yy0=yy1;
        p(i,1)=xx0;
        p(i,3)=yy0;
    
    end
end
for i=1:length(t(:,1))
    [a1,b1]=max(p(t(i,1:3),3));
    [a2,b2]=min(p(t(i,1:3),3));
    if a1-a2==0
        k=0;
    else
    k=(a1-a2)/(p(t(i,b1),1)-p(t(i,b2),1));
    end
    alpha(i)=atan(k);
end
t(:,4)=alpha(:);    
simpplot(p,t(:,1:3));

view([0,0])

save point.mat p;
save triangle.mat t;