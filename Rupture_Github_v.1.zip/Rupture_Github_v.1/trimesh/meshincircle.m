clc
clear

%% 本程序生成p的坐标依次是：走向坐标，垂向坐标（向下为正），垂直走向坐标

addpath([fileparts(pwd),'/toolkit']);

% s1=[-5,5,0];
% s2=[50,5,0];
% s3=[50,-5,0];
% s4=[-5,-5,0];
% x1=[s1(1),s2(1),s3(1),s4(1),s1(1)];
% x2=[s1(2),s2(2),s3(2),s4(2),s1(2)];
% x3=[s1(3),s2(3),s3(3),s4(3),s1(3)];
% curvehandle1=plot3(x1,x2,x3,'Color','k')
% set(curvehandle1,'linesmoothing','on')
% fill3(x1,x2,x3,[0.8,0.8,0.8])
% alpha(0.3)
% hold on

% m1=[-5,0,0];
% m2=[50,0,0];
% x1=[m1(1),m2(1)];
% x2=[m1(2),m2(2)];
% x3=[m1(3),m2(3)];
% curvehandle2=plot3(x1,x2,x3,'--','Color','k')
% set(curvehandle2,'linesmoothing','on')
% hold on

% f1=[0,0,0];
% f2=[30,0,0];
% f3=[45,0,0];
% f4=[45,0,-10];
% f5=[30,0,-10];
% f6=[0,0,-10];
% x1=[f1(1),f2(1),f3(1),f4(1),f5(1),f6(1),f1(1)];
% x2=[f1(2),f2(2),f3(2),f4(2),f5(2),f6(2),f1(2)];
% x3=[f1(3),f2(3),f3(3),f4(3),f5(3),f6(3),f1(3)];
% curvehandle3=plot3(x1,x2,x3,'Color','k','LineWidth',2)
% set(curvehandle3,'linesmoothing','on')
% hold on
% 
% b1=f2;
% b2=[30+15*cos(15/180*pi),-15*sin(15/180*pi),0];
% b3=[30+15*cos(15/180*pi),-15*sin(15/180*pi),-10];
% b4=f5;
% x1=[b1(1),b2(1),b3(1),b4(1),b1(1)];
% x2=[b1(2),b2(2),b3(2),b4(2),b1(2)];
% x3=[b1(3),b2(3),b3(3),b4(3),b1(3)];
% curvehandle4=plot3(x1,x2,x3,'Color','k','LineWidth',2)
% set(curvehandle4,'linesmoothing','on')

% axis([-5,50,-5,5,-15,5])
% hold on








%% 调整参数
circle_x=0; % 圆心x坐标
circle_y=0; % 圆心y坐标
circle_r=2.5; % 圆的半径
circle_size=1; % 圆内三角形单元尺寸
p_len=30; % 断层面长
p_wid=10; % 断层面宽
p_size=1; % 断层面三角形网格尺寸

fi2=-pi/12; % 分叉面一角度
fi3=0; % 分叉面二角度
p2_len=15; % 分叉面一长
p2_wid=10; % 分叉面一宽
p2_size=1; % 分叉面一三角形单元尺寸
p3_len=15; % 分叉面二长
p3_wid=10; % 分叉面二宽
p3_size=1; % 分叉面二三角形单元尺寸
fx2=cos(fi2);
fz2=sin(fi2);
fx3=cos(fi3);
fz3=sin(fi3);

%% 计算网格坐标
% 画圆
fd=@(p) dcircle(p,circle_x,circle_y,circle_r);
[p,t]=distmesh2d(fd,@huniform,circle_size,[circle_x-3*circle_r,circle_y-3*circle_r;circle_x+3*circle_r,circle_y+3*circle_r],[]);
% 画圆外的正方形框
% 注释一下：
% p是圆中点的坐标；
% t是圆中各三角形单元三个顶点的序号；
% s是圆中所有边的端点坐标序号，到此为止的序号都对应p的序号；
% s_bound是找到的圆的边界点的序号，这个序号与之前不同，对应的是s的序号；
% p_bound也是圆的边界点的序号，只不过对应p的序号；
% 更改边界点的坐标就可以直接更改p_bound;
s=get_side(t); % 获得圆中所有三角形网格边的端点坐标序号
[s_t,s_bound]=get_s_t(s,t); % s_bound为圆的边界点序号
[p_bound,p_bound_point]=bound_point(s_bound,p,s); % 获取边界点序号以及坐标
fd=@(p) drectangle(p,-p_len/2,p_len/2,-p_wid/2,p_wid/2);
pv1=[p_bound_point;-p_len/2,-p_wid/2;-p_len/2,p_wid/2;p_len/2,-p_wid/2;p_len/2,p_wid/2];

circle_x=7.5; % 圆心x坐标
circle_y=0; % 圆心y坐标
circle_r=2.5; % 圆的半径
circle_size=1; % 圆内三角形单元尺寸
fd=@(p) dcircle(p,circle_x,circle_y,circle_r);
[p,t]=distmesh2d(fd,@huniform,circle_size,[circle_x-3*circle_r,circle_y-3*circle_r;circle_x+3*circle_r,circle_y+3*circle_r],[]);
s=get_side(t); % 获得圆中所有三角形网格边的端点坐标序号
[s_t,s_bound]=get_s_t(s,t); % s_bound为圆的边界点序号
[p_bound,p_bound_point]=bound_point(s_bound,p,s); % 获取边界点序号以及坐标
fd=@(p) drectangle(p,-p_len/2,p_len/2,-p_wid/2,p_wid/2);
pv2=[p_bound_point;-p_len/2,-p_wid/2;-p_len/2,p_wid/2;p_len/2,-p_wid/2;p_len/2,p_wid/2];

circle_x=-7.5; % 圆心x坐标
circle_y=0; % 圆心y坐标
circle_r=2.5; % 圆的半径
circle_size=1; % 圆内三角形单元尺寸
fd=@(p) dcircle(p,circle_x,circle_y,circle_r);
[p,t]=distmesh2d(fd,@huniform,circle_size,[circle_x-3*circle_r,circle_y-3*circle_r;circle_x+3*circle_r,circle_y+3*circle_r],[]);
s=get_side(t); % 获得圆中所有三角形网格边的端点坐标序号
[s_t,s_bound]=get_s_t(s,t); % s_bound为圆的边界点序号
[p_bound,p_bound_point]=bound_point(s_bound,p,s); % 获取边界点序号以及坐标
fd=@(p) drectangle(p,-p_len/2,p_len/2,-p_wid/2,p_wid/2);
pv3=[p_bound_point;-p_len/2,-p_wid/2;-p_len/2,p_wid/2;p_len/2,-p_wid/2;p_len/2,p_wid/2];

pv=[pv1;pv2;pv3];
[p1,t1]=distmesh2d(fd,@huniform,p_size,[-p_len/2,-p_wid/2;p_len/2,p_wid/2],pv);
p1(:,1)=p1(:,1)+15;
p1(:,2)=p1(:,2)+5;

fd=@(p2) drectangle(p2,0,p2_len,0,p2_wid);
[p2,t2]=distmesh2d(fd,@huniform,p2_size,[0,0;p2_len,p2_wid],[0,0;0,p2_wid;p2_len,0;p2_len,p2_wid]);
fd=@(p3) drectangle(p3,0,p3_len,0,p3_wid);
[p3,t3]=distmesh2d(fd,@huniform,p3_size,[0,0;p3_len,p3_wid],[0,0;0,p3_wid;p3_len,0;p3_len,p3_wid]);
% 依次进行弯折与平移
p1(:,3)=0;
p2(:,3)=p2(:,1)*fz2;
p2(:,1)=p2(:,1)*fx2+p_len; % 弯折网格投影并与基础网格在x方向上对齐
p3(:,3)=p3(:,1)*fz3;
p3(:,1)=p3(:,1)*fx3+p_len; 
% 以上进行了投影，接下来就是连接
n=size(p1,1); % p1网格的节点数量
m=size(p2,1);
t2=t2+n; % 使得合并之后t2中的值能对应p2
t3=t3+n+m;
t1(:,4)=0;
t2(:,4)=fi2;
t3(:,4)=fi3;
p=[p1;p2;p3];
t=[t1;t2;t3];

% trans=[1,0,0;0,0,-1;0,1,0];
% p=p*trans;

% t(:,4)=0;
simpplot(p,t(:,1:3));

%% 中间有圆形区域的平面网格
save point.mat p;
save triangle.mat t;
axis off