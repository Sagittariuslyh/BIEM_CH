%% 本程序生成p的坐标依次是：走向坐标，垂向坐标（向下为正），垂直走向坐标

addpath([fileparts(pwd),'/toolkit']);

%% 调整参数
fi2=-pi/6; % 分叉面一角度
fi3=0; % 分叉面二角度
p1_len=16.5; % 主平面长
p1_wid=15; % 主平面宽
p1_size=0.375; % 主平面三角形单元尺寸
p2_len=12; % 分叉面一长
p2_wid=15; % 分叉面一宽
p2_size=0.375; % 分叉面一三角形单元尺寸
p3_len=12; % 分叉面二长
p3_wid=15; % 分叉面二宽
p3_size=0.375; % 分叉面二三角形单元尺寸

%% 绘制网格
fx2=cos(fi2);
fz2=sin(fi2);
fx3=cos(fi3);
fz3=sin(fi3);
Ln1=round(p1_len/p1_size);
Lm1=round(p1_wid/p1_size);
p1=zeros((Ln1+1)*(Lm1+1),3);
t1=zeros(Ln1*Lm1,5);
p1(:,3)=0; % 平面断层
t1(:,5)=0;
num=0; % 标记网格序号
for i=1:Ln1
    for j=1:Lm1
        num=num+1;
        A=[(i-1)*p1_size,(j-1)*p1_size];
        B=[(i-1)*p1_size,j*p1_size];
        C=[i*p1_size,j*p1_size];
        D=[i*p1_size,(j-1)*p1_size];
        for k=1:2
            p1(round((i-1)*(Lm1+1)+j),k)=A(k);
            p1(round((i-1)*(Lm1+1)+j+1),k)=B(k);
            p1(round(i*(Lm1+1)+j+1),k)=C(k);
            p1(round(i*(Lm1+1)+j),k)=D(k);
        end
        t1((i-1)*Lm1+j,1)=round((i-1)*(Lm1+1)+j);
        t1((i-1)*Lm1+j,2)=round((i-1)*(Lm1+1)+j+1);
        t1((i-1)*Lm1+j,3)=round(i*(Lm1+1)+j+1);
        t1((i-1)*Lm1+j,4)=round(i*(Lm1+1)+j);
    end
end

Ln2=round(p2_len/p2_size);
Lm2=round(p2_wid/p2_size);
p2=zeros((Ln2+1)*(Lm2+1),3);
t2=zeros(Ln2*Lm2,5);
p2(:,3)=0; % 平面断层
t2(:,5)=0;
num=0; % 标记网格序号
for i=1:Ln2
    for j=1:Lm2
        num=num+1;
        A=[(i-1)*p2_size,(j-1)*p2_size];
        B=[(i-1)*p2_size,j*p2_size];
        C=[i*p2_size,j*p2_size];
        D=[i*p2_size,(j-1)*p2_size];
        for k=1:2
            p2(round((i-1)*(Lm2+1)+j),k)=A(k);
            p2(round((i-1)*(Lm2+1)+j+1),k)=B(k);
            p2(round(i*(Lm2+1)+j+1),k)=C(k);
            p2(round(i*(Lm2+1)+j),k)=D(k);
        end
        t2((i-1)*Lm2+j,1)=round((i-1)*(Lm2+1)+j);
        t2((i-1)*Lm2+j,2)=round((i-1)*(Lm2+1)+j+1);
        t2((i-1)*Lm2+j,3)=round(i*(Lm2+1)+j+1);
        t2((i-1)*Lm2+j,4)=round(i*(Lm2+1)+j);
    end
end

Ln3=round(p3_len/p3_size);
Lm3=round(p3_wid/p3_size);
p3=zeros((Ln3+1)*(Lm3+1),3);
t3=zeros(Ln3*Lm3,5);
p3(:,3)=0; % 平面断层
t3(:,5)=0;
num=0; % 标记网格序号
for i=1:Ln3
    for j=1:Lm3
        num=num+1;
        A=[(i-1)*p3_size,(j-1)*p3_size];
        B=[(i-1)*p3_size,j*p3_size];
        C=[i*p3_size,j*p3_size];
        D=[i*p3_size,(j-1)*p3_size];
        for k=1:2
            p3(round((i-1)*(Lm3+1)+j),k)=A(k);
            p3(round((i-1)*(Lm3+1)+j+1),k)=B(k);
            p3(round(i*(Lm3+1)+j+1),k)=C(k);
            p3(round(i*(Lm3+1)+j),k)=D(k);
        end
        t3((i-1)*Lm3+j,1)=round((i-1)*(Lm3+1)+j);
        t3((i-1)*Lm3+j,2)=round((i-1)*(Lm3+1)+j+1);
        t3((i-1)*Lm3+j,3)=round(i*(Lm3+1)+j+1);
        t3((i-1)*Lm3+j,4)=round(i*(Lm3+1)+j);
    end
end

% 依次进行弯折与平移
p1(:,3)=0;
p2(:,3)=p2(:,1)*fz2-0.05;
p2(:,1)=p2(:,1)*fx2+p1_len+0.05*sqrt(3); % 弯折网格投影并与基础网格在x方向上对齐
p3(:,3)=p3(:,1)*fz3;
p3(:,1)=p3(:,1)*fx3+p1_len; 
% 以上进行了投影，接下来就是连接
n=size(p1,1); % p1网格的节点数量
m=size(p2,1);
t2=t2+n; % 使得合并之后t2中的值能对应p2
t3=t3+n+m;
t1(:,5)=0;
t2(:,5)=fi2;
t3(:,5)=fi3;
p=[p1;p2;p3];
t=[t1;t2;t3];

% t(:,5)=-t(:,5);

%% 分叉断层
save point.mat p;
save triangle.mat t;
simpplot(p,t(:,1:4));
whos p
whos t

xlabel('x1')
ylabel('x2')
zlabel('x3')