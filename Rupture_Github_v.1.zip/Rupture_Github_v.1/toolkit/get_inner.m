function t_inner=get_inner(p,t)
n=size(t,1);
for i=1:n
    x1=p(t(i,1),1);
    y1=p(t(i,1),2);
    x2=p(t(i,2),1);
    y2=p(t(i,2),2);
    x3=p(t(i,3),1);
    y3=p(t(i,3),2);
    r12=sqrt((x1-x2)^2+(y1-y2)^2);
    r13=sqrt((x1-x3)^2+(y1-y3)^2);
    r32=sqrt((x3-x2)^2+(y3-y2)^2);
    t_inner(i,1)=(x1*r32+x2*r13+x3*r12)/(r12+r13+r32);
    t_inner(i,2)=(y1*r32+y2*r13+y3*r12)/(r12+r13+r32);
end
