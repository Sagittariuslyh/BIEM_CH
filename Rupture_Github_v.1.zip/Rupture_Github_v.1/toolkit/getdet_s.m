function det_s=getdet_s(p,t)
n=size(t,1);
det_s=10000;
typeflag=size(t,2);
if typeflag==4
    type='unstructed' % �ǽṹ������
elseif typeflag==5
    type='structed' % �ṹ������
end
for i=1:n
    switch type
        case 'unstructed'
            a=((p(t(i,1),1)-p(t(i,2),1))^2+(p(t(i,1),2)-p(t(i,2),2))^2)^0.5; %%���������εı߳�
            b=((p(t(i,2),1)-p(t(i,3),1))^2+(p(t(i,2),2)-p(t(i,3),2))^2)^0.5;
            c=((p(t(i,3),1)-p(t(i,1),1))^2+(p(t(i,3),2)-p(t(i,1),2))^2)^0.5;
            %%�����ڽ�Բ�뾶��ʽ
            r=(((a+b-c)*(a-b+c)*(b+c-a)/(a+b+c))^0.5)/2;
        case 'structed'
            r=norm(p(t(i,1),:)-p(t(i,2),:))/2;
        otherwise
    end
    if r<det_s
        det_s=r;
    end
end