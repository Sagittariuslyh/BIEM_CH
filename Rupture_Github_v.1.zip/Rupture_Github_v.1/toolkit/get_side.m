function s=get_side(t)
s=[t(:,[1,2]);t(:,[1,3]);t(:,[2,3])];       
s=unique(sort(s,2),'rows');    
    