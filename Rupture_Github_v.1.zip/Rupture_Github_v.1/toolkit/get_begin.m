function t_begin=get_begin(p,t,r,x0,y0)
n=size(t,1);
num=0;
for i=1:n
    x=(p(t(i,1),1)+p(t(i,2),1)+p(t(i,3),1))/3;
    y=(p(t(i,1),2)+p(t(i,2),2)+p(t(i,3),2))/3;
    if (x-x0)*(x-x0)+(y-y0)*(y-y0)<r*r
        num=num+1;
        t_begin(num)=i;
    end
end
fname=['tri_begin_',num2str(n)];
save(fname,'t_begin');