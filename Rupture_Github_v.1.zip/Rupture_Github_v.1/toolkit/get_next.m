function t_next=get_next(t)
n=size(t,1);
for i=1:n
    num=1;
    for j=1:n
        c=intersect(t(i,:),t(j,:));
        if length(c)==2
            t_next(i,1)=num;
            num=num+1;
            t_next(i,num)=j;
        end
    end
end
fname=['tri_next_',num2str(n)];
save(fname,'t_next');