function p=transpara(p)
n=size(p,1);
for i=1:n
    a=p(i,1);
fun=@(x)((1+x.^2).^0.5).*0.5.*x+0.5.*log(((1+x.^2).^0.5)+x)-a;
p(i,1)=fzero(fun,a);
p(i,3)=0.5.*p(i,1).^2;
end
end