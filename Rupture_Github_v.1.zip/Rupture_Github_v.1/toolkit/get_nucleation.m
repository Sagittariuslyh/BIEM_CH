function t_nucleation=get_nucleation(p,t,r,x0,z0)
n=size(t,1);
num=0;
for i=1:n
    x=(p(t(i,1),1)+p(t(i,2),1)+p(t(i,3),1))/3;
    z=(p(t(i,1),2)+p(t(i,2),2)+p(t(i,3),2))/3;
    if (x-x0)*(x-x0)+(z-z0)*(z-z0)<r*r
        num=num+1;
        t_nucleation(num)=i;
    end
end
